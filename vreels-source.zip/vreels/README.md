# vreels

Gallery foto + pemutar video Android native, **offline**, tanpa iklan/analytics/izin internet, dengan **desain bergaya Spotify** (tema gelap `#121212`, aksen hijau, bottom navigation, rak horizontal, daftar baris, tombol play bulat). Terinspirasi gayanya saja; tidak memakai nama, logo, atau aset Spotify. Target: Android 14+ (API 34), Kotlin + Jetpack Compose + AndroidX Media3.

> **Status jujur:** source lengkap, tetapi **belum pernah dikompilasi menjadi APK**. Lihat `BUILD_REPORT.md` dan `CLAUDE_CODE_HANDOFF.md`.

## Perilaku yang dijaga (acceptance-critical)
- **Tap di area video kosong hanya menampilkan/menyembunyikan kontrol. Tidak pernah Pause/Play.** Play/Pause hanya lewat tombolnya.
- Zona gesture ditentukan dari **posisi sentuhan awal**: kiri ≈28% = brightness, kanan ≈28% = volume (drag vertikal), tengah = swipe vertikal: **atas = video berikutnya, bawah = sebelumnya** (autoplay, tetap fullscreen).
- Tombol dan timeline berada di layer di atas surface gesture, jadi selalu diprioritaskan dan tidak diteruskan ke video.
- Swipe sah bila gerak vertikal ≥ 1,3× horizontal dan melewati ambang jarak; tap tidak pernah dianggap swipe.
- Batas antrean: berhenti (default) / ulang / tampilkan pesan.
- Brightness hanya mengubah jendela player (bukan setelan sistem). Volume memakai volume media Android.

## Desain (gaya Spotify)
- **Beranda:** sapaan sesuai jam, chip pil Semua/Video/Foto, 6 ubin folder cepat, rak "Video terbaru" / "Foto terbaru" / "Folder lainnya".
- **Cari:** kolom putih membulat, ubin "Jelajahi semua" berwarna, hasil berupa baris dengan thumbnail.
- **Pustaka:** daftar folder bergaya "Your Library" + pinned "Semua video/foto", pengurutan.
- **Halaman folder/koleksi:** header gradien dengan sampul besar, tombol play hijau bulat (memutar video pertama, lanjut otomatis), tombol ganti daftar/grid.
- **Player:** judul tebal, tombol minimize (panah bawah), tombol play/pause lingkaran putih, timeline putih tipis.
- Aksen bisa diganti di Pengaturan (Hijau/Cyan/Coral/Amber).

## Struktur
```
app/src/main/java/com/vreels/player/
  MainActivity.kt                 izin media, navigasi gallery/settings/foto
  core/{model,media,settings,design,common}
  feature/gallery                 grid, folder, filter, cari, sort, penampil foto
  feature/player                  PlayerActivity (ExoPlayer), PlayerScreen (gesture + kontrol)
  feature/settings                halaman pengaturan
  playback/gestures               GestureClassifier (murni, teruji unit)
  playback/queue                  QueueNavigator, antrean antar-layar
app/src/test/                     unit test gesture & antrean
scripts/build-and-verify.sh       build + verifikasi APK (untuk Claude Code)
```

## Build
Perlu JDK 17+, Android SDK (platform 36 + build-tools) dan internet saat build. Paling mudah: ikuti `CLAUDE_CODE_HANDOFF.md`.
Atau manual: `gradle wrapper --gradle-version 8.13 && ./gradlew assembleDebug`.

## Belum diimplementasikan (dibanding spesifikasi)
Playlist/favorit (Room), subtitle delay & audio delay, rotasi video 90° (yang ada: kunci orientasi), rasio manual & mode "Original" (yang ada: Fit/Crop/Stretch/Lebar/Tinggi), tampilan buffer di timeline, ukuran ikon per-tombol, ukuran timeline, warna ikon bebas, lock controls, background audio, folder hidden, sumber folder via SAF (yang ada: buka satu file), pengaturan warna/posisi subtitle, speed & repeat default, zoom/pinch foto, tes instrumented/UI, signing release.

## Build lewat GitHub Actions (tanpa Android Studio)
1. Buat repository baru di GitHub (disarankan **Private**) lalu unggah seluruh isi folder ini, termasuk folder `.github`.
2. Buka tab **Actions** → workflow **Build APK** (jalan otomatis setiap push, atau tekan *Run workflow*).
3. Setelah hijau, buka run tersebut → bagian **Artifacts** → unduh `vreels-debug-apk` (berisi APK + SHA256SUMS). Jika merah, buka log langkah yang gagal dan kirim ke Claude untuk diperbaiki.
