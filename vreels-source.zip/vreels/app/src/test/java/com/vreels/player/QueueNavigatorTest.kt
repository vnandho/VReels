package com.vreels.player

import com.vreels.player.core.settings.QueueBoundary
import com.vreels.player.playback.queue.NavResult
import com.vreels.player.playback.queue.QueueNavigator
import org.junit.Assert.assertEquals
import org.junit.Test

class QueueNavigatorTest {
    @Test fun movesNormallyInsideQueue() {
        assertEquals(NavResult(3, false), QueueNavigator.target(2, 5, true, QueueBoundary.STOP))
        assertEquals(NavResult(1, false), QueueNavigator.target(2, 5, false, QueueBoundary.STOP))
    }

    @Test fun stopsAtLastAndFirstByDefault() {
        assertEquals(NavResult(null, false), QueueNavigator.target(4, 5, true, QueueBoundary.STOP))
        assertEquals(NavResult(null, false), QueueNavigator.target(0, 5, false, QueueBoundary.STOP))
    }

    @Test fun messageModeReportsBoundary() {
        assertEquals(NavResult(null, true), QueueNavigator.target(4, 5, true, QueueBoundary.MESSAGE))
    }

    @Test fun wrapModeLoopsBothWays() {
        assertEquals(NavResult(0, false), QueueNavigator.target(4, 5, true, QueueBoundary.WRAP))
        assertEquals(NavResult(4, false), QueueNavigator.target(0, 5, false, QueueBoundary.WRAP))
    }

    @Test fun singleItemOrEmptyQueueNeverMoves() {
        assertEquals(NavResult(null, false), QueueNavigator.target(0, 1, true, QueueBoundary.WRAP))
        assertEquals(NavResult(null, false), QueueNavigator.target(0, 0, true, QueueBoundary.WRAP))
    }
}
