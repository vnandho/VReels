package com.vreels.player

import com.vreels.player.playback.gestures.GestureClassifier
import com.vreels.player.playback.gestures.GestureConfig
import com.vreels.player.playback.gestures.GestureEvent
import com.vreels.player.playback.gestures.Zone
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GestureClassifierTest {
    private val w = 1000f
    private val h = 2000f
    private fun classifier(cfg: GestureConfig = GestureConfig()) = GestureClassifier(cfg, w, h)

    /** Jalankan satu gesture; kembalikan semua event non-None sesuai urutan. */
    private fun drag(c: GestureClassifier, from: Pair<Float, Float>, to: Pair<Float, Float>, steps: Int = 10): List<GestureEvent> {
        val out = mutableListOf<GestureEvent>()
        c.onDown(from.first, from.second)
        for (i in 1..steps) {
            val x = from.first + (to.first - from.first) * i / steps
            val y = from.second + (to.second - from.second) * i / steps
            out += c.onMove(x, y)
        }
        out += c.onUp(to.first, to.second)
        return out.filter { it != GestureEvent.None }
    }

    @Test fun zonesAreDecidedByStartPosition() {
        val c = classifier()
        assertEquals(Zone.LEFT, c.zoneAt(100f))
        assertEquals(Zone.CENTER, c.zoneAt(500f))
        assertEquals(Zone.RIGHT, c.zoneAt(900f))
    }

    @Test fun plainTapIsTapAndNotSwipe() {
        val c = classifier()
        c.onDown(500f, 1000f)
        assertEquals(GestureEvent.Tap, c.onUp(500f, 1000f))
    }

    @Test fun tinyJitterStillCountsAsTap() {
        val c = classifier()
        c.onDown(500f, 1000f)
        assertEquals(GestureEvent.None, c.onMove(505f, 1006f))
        assertEquals(GestureEvent.Tap, c.onUp(505f, 1006f))
    }

    @Test fun centerSwipeUpGoesToNextVideo() {
        assertEquals(listOf<GestureEvent>(GestureEvent.Next), drag(classifier(), 500f to 1400f, 500f to 600f))
    }

    @Test fun centerSwipeDownGoesToPreviousVideo() {
        assertEquals(listOf<GestureEvent>(GestureEvent.Previous), drag(classifier(), 500f to 600f, 500f to 1400f))
    }

    @Test fun shortCenterSwipeBelowThresholdDoesNothing() {
        assertTrue(drag(classifier(), 500f to 1000f, 500f to 900f).isEmpty())
    }

    @Test fun leftDragUpIncreasesBrightnessNotNavigation() {
        val events = drag(classifier(), 100f to 1500f, 100f to 500f)
        assertTrue(events.isNotEmpty())
        assertTrue(events.all { it is GestureEvent.Brightness && it.delta > 0f })
    }

    @Test fun rightDragDownDecreasesVolume() {
        val events = drag(classifier(), 900f to 500f, 900f to 1500f)
        assertTrue(events.isNotEmpty())
        assertTrue(events.all { it is GestureEvent.Volume && it.delta < 0f })
    }

    @Test fun fullHeightDragChangesByFullRangeAtDefaultSensitivity() {
        val events = drag(classifier(), 100f to 2000f, 100f to 0f, steps = 20)
        val total = events.filterIsInstance<GestureEvent.Brightness>().sumOf { it.delta.toDouble() }
        assertTrue(total in 0.85..1.0) // sedikit hilang karena touch slop
    }

    @Test fun zoneStaysFixedWhenFingerDriftsIntoCenter() {
        val c = classifier()
        c.onDown(100f, 1500f)
        var brightness = 0
        for (i in 1..10) {
            val e = c.onMove(100f + i * 30f, 1500f - i * 100f) // drift ke kanan, tetap dominan vertikal
            if (e is GestureEvent.Brightness) brightness++
            assertTrue(e !is GestureEvent.Next && e !is GestureEvent.Previous)
        }
        assertTrue(brightness > 0)
        assertEquals(GestureEvent.None, c.onUp(400f, 500f))
    }

    @Test fun horizontalDragIsIgnoredEverywhere() {
        assertTrue(drag(classifier(), 500f to 1000f, 900f to 1050f).isEmpty())
        assertTrue(drag(classifier(), 100f to 1000f, 600f to 1050f).isEmpty())
    }

    @Test fun diagonalBelowRatioIsRejected() {
        // dy=100, dx=100 -> rasio 1.0 < 1.3
        assertTrue(drag(classifier(), 500f to 1000f, 600f to 900f).isEmpty())
    }

    @Test fun disabledBrightnessGestureDoesNothingOnLeft() {
        val c = classifier(GestureConfig(brightnessEnabled = false))
        assertTrue(drag(c, 100f to 1500f, 100f to 500f).isEmpty())
    }

    @Test fun disabledVolumeGestureDoesNothingOnRight() {
        val c = classifier(GestureConfig(volumeEnabled = false))
        assertTrue(drag(c, 900f to 1500f, 900f to 500f).isEmpty())
    }

    @Test fun invertFlipsDirection() {
        val events = drag(classifier(GestureConfig(invert = true)), 100f to 1500f, 100f to 500f)
        assertTrue(events.all { it is GestureEvent.Brightness && it.delta < 0f })
    }

    @Test fun wideSideZoneChangesWhereBrightnessStarts() {
        val c = classifier(GestureConfig(sideZoneFraction = 0.4f))
        assertEquals(Zone.LEFT, c.zoneAt(350f))
        assertEquals(Zone.RIGHT, c.zoneAt(650f))
    }

    @Test fun cancelThenNewGestureStartsClean() {
        val c = classifier()
        c.onDown(100f, 1500f); c.onMove(100f, 1200f); c.cancel()
        assertEquals(GestureEvent.None, c.onUp(100f, 1200f))
        assertEquals(listOf<GestureEvent>(GestureEvent.Next), drag(c, 500f to 1400f, 500f to 600f))
    }
}
