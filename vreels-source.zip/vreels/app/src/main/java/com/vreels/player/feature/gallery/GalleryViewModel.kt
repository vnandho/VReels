package com.vreels.player.feature.gallery

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vreels.player.core.media.MediaRepository
import com.vreels.player.core.model.Folder
import com.vreels.player.core.model.GalleryItem
import com.vreels.player.core.model.MediaType
import com.vreels.player.core.model.QueueEntry
import com.vreels.player.core.model.SortOrder
import com.vreels.player.core.model.TypeFilter
import com.vreels.player.core.settings.QueueScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class GalleryViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = MediaRepository(app)
    private val all = MutableStateFlow<List<GalleryItem>>(emptyList())

    val loading = MutableStateFlow(false)
    val typeFilter = MutableStateFlow(TypeFilter.ALL)
    val query = MutableStateFlow("")
    val sort = MutableStateFlow(SortOrder.NEWEST)
    val folderId = MutableStateFlow<Long?>(null)
    /** true = tampilkan daftar folder, false = grid media. */
    val foldersView = MutableStateFlow(false)

    val visible: StateFlow<List<GalleryItem>> =
        combine(all, typeFilter, query, sort, folderId) { items, type, q, order, folder ->
            items.asSequence()
                .filter { matchesType(it, type) }
                .filter { folder == null || it.bucketId == folder }
                .filter { q.isBlank() || it.name.contains(q.trim(), ignoreCase = true) }
                .toList()
                .sortedWith(comparator(order))
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val folders: StateFlow<List<Folder>> =
        combine(all, typeFilter, query, sort) { items, type, q, order ->
            items.filter { matchesType(it, type) && (q.isBlank() || it.name.contains(q.trim(), true)) }
                .groupBy { it.bucketId }
                .map { (id, list) ->
                    val newest = list.maxBy { it.dateAdded }
                    Folder(id, newest.bucketName, list.size, newest)
                }
                .let { list ->
                    when (order) {
                        SortOrder.NEWEST -> list.sortedByDescending { it.cover.dateAdded }
                        SortOrder.OLDEST -> list.sortedBy { it.cover.dateAdded }
                        SortOrder.NAME -> list.sortedBy { it.name.lowercase() }
                        SortOrder.SIZE, SortOrder.DURATION -> list.sortedByDescending { it.count }
                    }
                }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun refresh() {
        viewModelScope.launch {
            loading.value = true
            all.value = repo.load()
            loading.value = false
        }
    }

    fun openFolder(folder: Folder) {
        folderId.value = folder.id
        foldersView.value = false
    }

    /** Kembali dari isi folder ke daftar folder. Mengembalikan true bila ada yang ditangani. */
    fun backToFolders(): Boolean {
        if (folderId.value == null) return false
        folderId.value = null
        return true
    }

    /** Antrean video dari konteks asal: folder yang sama, atau semua video, mengikuti urutan sort aktif. */
    fun buildQueue(clicked: GalleryItem, scope: QueueScope): Pair<List<QueueEntry>, Int> {
        val videos = all.value
            .filter { it.type == MediaType.VIDEO }
            .filter { scope == QueueScope.ALL || it.bucketId == clicked.bucketId }
            .sortedWith(comparator(sort.value))
        val index = videos.indexOfFirst { it.id == clicked.id }.coerceAtLeast(0)
        return videos.map { QueueEntry(it.uri.toString(), it.name) } to index
    }

    private fun matchesType(item: GalleryItem, f: TypeFilter) = when (f) {
        TypeFilter.ALL -> true
        TypeFilter.VIDEO -> item.type == MediaType.VIDEO
        TypeFilter.PHOTO -> item.type == MediaType.IMAGE
    }

    private fun comparator(order: SortOrder): Comparator<GalleryItem> = when (order) {
        SortOrder.NEWEST -> compareByDescending { it.dateAdded }
        SortOrder.OLDEST -> compareBy { it.dateAdded }
        SortOrder.NAME -> compareBy { it.name.lowercase() }
        SortOrder.SIZE -> compareByDescending { it.sizeBytes }
        SortOrder.DURATION -> compareByDescending { it.durationMs }
    }
}
