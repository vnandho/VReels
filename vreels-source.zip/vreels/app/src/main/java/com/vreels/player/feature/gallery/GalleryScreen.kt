@file:OptIn(ExperimentalMaterial3Api::class)

package com.vreels.player.feature.gallery

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.outlined.Home as OHome
import androidx.compose.material.icons.outlined.Search as OSearch
import androidx.compose.material.icons.outlined.VideoLibrary as OVideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.vreels.player.core.common.formatSize
import com.vreels.player.core.common.formatTime
import com.vreels.player.core.design.PillChip
import com.vreels.player.core.design.TilePalette
import com.vreels.player.core.design.VCard
import com.vreels.player.core.design.VSecondary
import com.vreels.player.core.media.ThumbnailLoader
import com.vreels.player.core.model.Folder
import com.vreels.player.core.model.GalleryItem
import com.vreels.player.core.model.MediaAccess
import com.vreels.player.core.model.MediaType
import com.vreels.player.core.model.SortOrder
import com.vreels.player.core.model.TypeFilter
import java.util.Calendar

private enum class Dest { HOME, SEARCH, LIBRARY }
private enum class SubPage { ALL_VIDEOS, ALL_PHOTOS }

private val sortLabels = mapOf(
    SortOrder.NEWEST to "Terbaru",
    SortOrder.OLDEST to "Terlama",
    SortOrder.NAME to "Nama",
    SortOrder.SIZE to "Ukuran / jumlah",
    SortOrder.DURATION to "Durasi video",
)

private fun GalleryItem.title() = name.substringBeforeLast('.')
private fun GalleryItem.subtitle() =
    if (type == MediaType.VIDEO) "Video • ${formatTime(durationMs)} • ${formatSize(sizeBytes)}" else "Foto • ${formatSize(sizeBytes)}"

private fun greeting(): String {
    val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when {
        h < 11 -> "Selamat pagi"
        h < 15 -> "Selamat siang"
        h < 18 -> "Selamat sore"
        else -> "Selamat malam"
    }
}

@Composable
fun GalleryScreen(
    vm: GalleryViewModel,
    gridColumns: Int,
    access: MediaAccess,
    onRequestAccess: () -> Unit,
    onOpenVideo: (GalleryItem) -> Unit,
    onOpenImage: (GalleryItem, List<GalleryItem>) -> Unit,
    onPickVideoFile: () -> Unit,
    onOpenSettings: () -> Unit,
    onSortChange: (SortOrder) -> Unit,
    @Suppress("UNUSED_PARAMETER") onGridChange: (Int) -> Unit,
) {
    val items by vm.visible.collectAsStateWithLifecycle()
    val folders by vm.folders.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val filter by vm.typeFilter.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val sort by vm.sort.collectAsStateWithLifecycle()
    val folderId by vm.folderId.collectAsStateWithLifecycle()

    var dest by rememberSaveable { mutableStateOf(Dest.HOME) }
    var sub by rememberSaveable { mutableStateOf<SubPage?>(null) }

    fun open(item: GalleryItem) {
        if (item.type == MediaType.VIDEO) onOpenVideo(item)
        else onOpenImage(item, items.filter { it.type == MediaType.IMAGE })
    }
    fun openAll(page: SubPage) {
        sub = page
        vm.typeFilter.value = if (page == SubPage.ALL_VIDEOS) TypeFilter.VIDEO else TypeFilter.PHOTO
    }

    BackHandler(enabled = sub != null || folderId != null) {
        if (folderId != null) vm.folderId.value = null
        else { sub = null; vm.typeFilter.value = TypeFilter.ALL }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            BottomNav(dest) { d ->
                dest = d; sub = null
                vm.folderId.value = null
                vm.typeFilter.value = TypeFilter.ALL
                if (d != Dest.SEARCH) vm.query.value = ""
            }
        },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            if (access == MediaAccess.PARTIAL) {
                Row(
                    Modifier.fillMaxWidth().background(VCard).padding(horizontal = 16.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("Akses sebagian: hanya media yang Anda pilih.", Modifier.weight(1f), fontSize = 12.sp, color = VSecondary)
                    TextButton(onClick = onRequestAccess) { Text("Pilih lagi") }
                }
            }
            Box(Modifier.weight(1f).fillMaxSize()) {
                when {
                    access == MediaAccess.DENIED -> PermissionPrompt(onRequestAccess, onPickVideoFile)
                    folderId != null -> {
                        val name = folders.firstOrNull { it.id == folderId }?.name ?: items.firstOrNull()?.bucketName ?: "Folder"
                        CollectionPage(
                            title = name,
                            items = items,
                            gridColumns = gridColumns,
                            gridDefault = false,
                            loading = loading,
                            onRefresh = { vm.refresh() },
                            onBack = { vm.folderId.value = null },
                            onOpen = ::open,
                        )
                    }
                    sub != null -> CollectionPage(
                        title = if (sub == SubPage.ALL_VIDEOS) "Semua video" else "Semua foto",
                        items = items,
                        gridColumns = gridColumns,
                        gridDefault = sub == SubPage.ALL_PHOTOS,
                        loading = loading,
                        onRefresh = { vm.refresh() },
                        onBack = { sub = null; vm.typeFilter.value = TypeFilter.ALL },
                        onOpen = ::open,
                    )
                    else -> when (dest) {
                        Dest.HOME -> HomeTab(
                            items = items, folders = folders, filter = filter, loading = loading,
                            onRefresh = { vm.refresh() },
                            onFilter = { vm.typeFilter.value = it },
                            onOpenSettings = onOpenSettings,
                            onOpenFolder = { vm.openFolder(it) },
                            onOpen = ::open,
                            onSeeAll = ::openAll,
                            onPickFile = onPickVideoFile,
                        )
                        Dest.SEARCH -> SearchTab(
                            items = items, folders = folders, query = query, filter = filter,
                            onQuery = { vm.query.value = it },
                            onFilter = { vm.typeFilter.value = it },
                            onOpenFolder = { vm.openFolder(it) },
                            onOpen = ::open,
                            onSeeAll = ::openAll,
                        )
                        Dest.LIBRARY -> LibraryTab(
                            items = items, folders = folders, sort = sort, loading = loading,
                            onRefresh = { vm.refresh() },
                            onSort = { vm.sort.value = it; onSortChange(it) },
                            onOpenSettings = onOpenSettings,
                            onOpenFolder = { vm.openFolder(it) },
                            onSeeAll = ::openAll,
                        )
                    }
                }
            }
        }
    }
}

// ---------------- Navigasi bawah ----------------

@Composable
private fun BottomNav(current: Dest, onSelect: (Dest) -> Unit) {
    val colors = NavigationBarItemDefaults.colors(
        selectedIconColor = Color.White, selectedTextColor = Color.White,
        unselectedIconColor = VSecondary, unselectedTextColor = VSecondary,
        indicatorColor = Color.Transparent,
    )
    val entries: List<Triple<Dest, String, Pair<ImageVector, ImageVector>>> = listOf(
        Triple(Dest.HOME, "Beranda", Icons.Filled.Home to Icons.Outlined.OHome),
        Triple(Dest.SEARCH, "Cari", Icons.Filled.Search to Icons.Outlined.OSearch),
        Triple(Dest.LIBRARY, "Pustaka", Icons.Filled.VideoLibrary to Icons.Outlined.OVideoLibrary),
    )
    NavigationBar(containerColor = Color(0xF2121212)) {
        entries.forEach { (d, label, icons) ->
            NavigationBarItem(
                selected = current == d,
                onClick = { onSelect(d) },
                icon = { Icon(if (current == d) icons.first else icons.second, label) },
                label = { Text(label, fontSize = 11.sp) },
                colors = colors,
            )
        }
    }
}

// ---------------- Beranda ----------------

@Composable
private fun HomeTab(
    items: List<GalleryItem>,
    folders: List<Folder>,
    filter: TypeFilter,
    loading: Boolean,
    onRefresh: () -> Unit,
    onFilter: (TypeFilter) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenFolder: (Folder) -> Unit,
    onOpen: (GalleryItem) -> Unit,
    onSeeAll: (SubPage) -> Unit,
    onPickFile: () -> Unit,
) {
    val accent = MaterialTheme.colorScheme.primary
    val bg = MaterialTheme.colorScheme.background
    val videos = items.filter { it.type == MediaType.VIDEO }
    val photos = items.filter { it.type == MediaType.IMAGE }

    PullToRefreshBox(isRefreshing = loading, onRefresh = onRefresh, modifier = Modifier.fillMaxSize()) {
        if (items.isEmpty() && folders.isEmpty() && !loading) {
            EmptyState(onPickFile)
        } else LazyColumn(
            Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(accent.copy(alpha = 0.35f), bg), endY = 1100f)),
            contentPadding = PaddingValues(bottom = 24.dp),
        ) {
            item {
                Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(greeting(), Modifier.weight(1f), fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    IconButton(onClick = onOpenSettings) { Icon(Icons.Filled.Settings, "Pengaturan") }
                }
            }
            item {
                Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillChip(filter == TypeFilter.ALL, { onFilter(TypeFilter.ALL) }, "Semua")
                    PillChip(filter == TypeFilter.VIDEO, { onFilter(TypeFilter.VIDEO) }, "Video")
                    PillChip(filter == TypeFilter.PHOTO, { onFilter(TypeFilter.PHOTO) }, "Foto")
                }
            }
            if (folders.isNotEmpty()) {
                item {
                    Column(Modifier.padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        folders.take(6).chunked(2).forEach { pair ->
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                pair.forEach { f -> QuickTile(f, Modifier.weight(1f)) { onOpenFolder(f) } }
                                if (pair.size == 1) Spacer(Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
            if (filter != TypeFilter.PHOTO && videos.isNotEmpty()) {
                item { SectionTitle("Video terbaru", "Lihat semua") { onSeeAll(SubPage.ALL_VIDEOS) } }
                item { Shelf { items(videos.take(12), key = { "v${it.id}" }) { ShelfCard(it) { onOpen(it) } } } }
            }
            if (filter != TypeFilter.VIDEO && photos.isNotEmpty()) {
                item { SectionTitle("Foto terbaru", "Lihat semua") { onSeeAll(SubPage.ALL_PHOTOS) } }
                item { Shelf { items(photos.take(12), key = { "p${it.id}" }) { ShelfCard(it) { onOpen(it) } } } }
            }
            if (folders.size > 6) {
                item { SectionTitle("Folder lainnya", null) {} }
                item { Shelf { items(folders.drop(6), key = { it.id }) { f -> FolderCard(f) { onOpenFolder(f) } } } }
            }
        }
    }
}

@Composable
private fun QuickTile(folder: Folder, modifier: Modifier, onClick: () -> Unit) {
    Row(
        modifier.height(56.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFF2A2A2A)).clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Thumb(folder.cover, 160, Modifier.size(56.dp))
        Text(folder.name, Modifier.padding(horizontal = 10.dp), fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun SectionTitle(title: String, action: String?, onAction: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 20.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f), fontSize = 22.sp, fontWeight = FontWeight.Bold)
        if (action != null) TextButton(onClick = onAction) { Text(action, color = VSecondary, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
    }
}

@Composable
private fun Shelf(content: LazyListScope.() -> Unit) {
    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), content = content)
}

@Composable
private fun ShelfCard(item: GalleryItem, onClick: () -> Unit) {
    Column(Modifier.width(140.dp).clickable(onClick = onClick)) {
        Thumb(item, 320, Modifier.size(140.dp).clip(RoundedCornerShape(6.dp)))
        Text(item.title(), Modifier.padding(top = 6.dp), fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(if (item.type == MediaType.VIDEO) "Video • ${formatTime(item.durationMs)}" else "Foto", fontSize = 12.sp, color = VSecondary, maxLines = 1)
    }
}

@Composable
private fun FolderCard(folder: Folder, onClick: () -> Unit) {
    Column(Modifier.width(140.dp).clickable(onClick = onClick)) {
        Thumb(folder.cover, 320, Modifier.size(140.dp).clip(RoundedCornerShape(6.dp)))
        Text(folder.name, Modifier.padding(top = 6.dp), fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text("${folder.count} item", fontSize = 12.sp, color = VSecondary)
    }
}

// ---------------- Cari ----------------

@Composable
private fun SearchTab(
    items: List<GalleryItem>,
    folders: List<Folder>,
    query: String,
    filter: TypeFilter,
    onQuery: (String) -> Unit,
    onFilter: (TypeFilter) -> Unit,
    onOpenFolder: (Folder) -> Unit,
    onOpen: (GalleryItem) -> Unit,
    onSeeAll: (SubPage) -> Unit,
) {
    Column(Modifier.fillMaxSize()) {
        Text("Cari", Modifier.padding(start = 16.dp, top = 16.dp, bottom = 12.dp), fontSize = 28.sp, fontWeight = FontWeight.Bold)
        TextField(
            value = query,
            onValueChange = onQuery,
            singleLine = true,
            placeholder = { Text("Video, foto, atau folder") },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { onQuery("") }) { Icon(Icons.Filled.Close, "Hapus teks") } },
            shape = RoundedCornerShape(8.dp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.White, unfocusedContainerColor = Color.White,
                focusedTextColor = Color.Black, unfocusedTextColor = Color.Black,
                focusedPlaceholderColor = Color(0xFF535353), unfocusedPlaceholderColor = Color(0xFF535353),
                focusedLeadingIconColor = Color.Black, unfocusedLeadingIconColor = Color.Black,
                focusedTrailingIconColor = Color.Black, unfocusedTrailingIconColor = Color.Black,
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                cursorColor = Color.Black,
            ),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        )
        if (query.isBlank()) {
            Text("Jelajahi semua", Modifier.padding(start = 16.dp, top = 20.dp, bottom = 8.dp), fontSize = 18.sp, fontWeight = FontWeight.Bold)
            val tiles: List<Triple<String, GalleryItem?, () -> Unit>> = buildList {
                add(Triple("Semua video", items.firstOrNull { it.type == MediaType.VIDEO }, { onSeeAll(SubPage.ALL_VIDEOS) }))
                add(Triple("Semua foto", items.firstOrNull { it.type == MediaType.IMAGE }, { onSeeAll(SubPage.ALL_PHOTOS) }))
                folders.forEach { f -> add(Triple(f.name, f.cover, { onOpenFolder(f) })) }
            }
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                gridItems(tiles.size) { i ->
                    val (title, art, click) = tiles[i]
                    BrowseTile(title, art, TilePalette[i % TilePalette.size], click)
                }
            }
        } else {
            Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PillChip(filter == TypeFilter.ALL, { onFilter(TypeFilter.ALL) }, "Semua")
                PillChip(filter == TypeFilter.VIDEO, { onFilter(TypeFilter.VIDEO) }, "Video")
                PillChip(filter == TypeFilter.PHOTO, { onFilter(TypeFilter.PHOTO) }, "Foto")
            }
            if (items.isEmpty()) {
                Text("Tidak ada hasil untuk \"$query\"", Modifier.padding(16.dp), color = VSecondary)
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(items, key = { "${it.type}-${it.id}" }) { MediaRow(it) { onOpen(it) } }
                }
            }
        }
    }
}

@Composable
private fun BrowseTile(title: String, art: GalleryItem?, color: Color, onClick: () -> Unit) {
    Box(Modifier.fillMaxWidth().height(100.dp).clip(RoundedCornerShape(8.dp)).background(color).clickable(onClick = onClick)) {
        Text(title, Modifier.padding(12.dp).fillMaxWidth(0.65f), fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis, color = Color.White)
        if (art != null) {
            Thumb(art, 200, Modifier.align(Alignment.BottomEnd).offset(x = 8.dp, y = 8.dp).size(64.dp).rotate(25f).clip(RoundedCornerShape(4.dp)))
        }
    }
}

// ---------------- Pustaka ----------------

@Composable
private fun LibraryTab(
    items: List<GalleryItem>,
    folders: List<Folder>,
    sort: SortOrder,
    loading: Boolean,
    onRefresh: () -> Unit,
    onSort: (SortOrder) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenFolder: (Folder) -> Unit,
    onSeeAll: (SubPage) -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    val videoCount = items.count { it.type == MediaType.VIDEO }
    val photoCount = items.count { it.type == MediaType.IMAGE }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Pustaka Anda", Modifier.weight(1f), fontSize = 24.sp, fontWeight = FontWeight.Bold)
            IconButton(onClick = onOpenSettings) { Icon(Icons.Filled.Settings, "Pengaturan") }
        }
        Box(Modifier.padding(start = 8.dp, bottom = 4.dp)) {
            TextButton(onClick = { menu = true }) {
                Icon(Icons.Filled.SwapVert, null, Modifier.size(18.dp))
                Text("  ${sortLabels.getValue(sort)}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                SortOrder.entries.forEach { order ->
                    DropdownMenuItem(
                        text = { Text((if (order == sort) "✓ " else "") + sortLabels.getValue(order)) },
                        onClick = { menu = false; onSort(order) },
                    )
                }
            }
        }
        PullToRefreshBox(isRefreshing = loading, onRefresh = onRefresh, modifier = Modifier.fillMaxSize()) {
            LazyColumn(Modifier.fillMaxSize()) {
                item {
                    LibraryRow(
                        art = { PinnedArt(Brush.linearGradient(listOf(Color(0xFF450AF5), Color(0xFFC4EFD9))), Icons.Filled.PlayArrow) },
                        title = "Semua video", subtitle = "Koleksi • $videoCount video",
                    ) { onSeeAll(SubPage.ALL_VIDEOS) }
                }
                item {
                    LibraryRow(
                        art = { PinnedArt(Brush.linearGradient(listOf(Color(0xFFE13300), Color(0xFFFFC857))), Icons.Filled.GridView) },
                        title = "Semua foto", subtitle = "Koleksi • $photoCount foto",
                    ) { onSeeAll(SubPage.ALL_PHOTOS) }
                }
                items(folders, key = { it.id }) { f ->
                    LibraryRow(
                        art = { Thumb(f.cover, 200, Modifier.size(56.dp).clip(RoundedCornerShape(4.dp))) },
                        title = f.name, subtitle = "Folder • ${f.count} item",
                    ) { onOpenFolder(f) }
                }
            }
        }
    }
}

@Composable
private fun PinnedArt(brush: Brush, icon: ImageVector) {
    Box(Modifier.size(56.dp).clip(RoundedCornerShape(4.dp)).background(brush), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = Color.White)
    }
}

@Composable
private fun LibraryRow(art: @Composable () -> Unit, title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        art()
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, fontSize = 13.sp, color = VSecondary, maxLines = 1)
        }
    }
}

// ---------------- Halaman koleksi (folder / semua video / semua foto) ----------------

@Composable
private fun CollectionPage(
    title: String,
    items: List<GalleryItem>,
    gridColumns: Int,
    gridDefault: Boolean,
    loading: Boolean,
    onRefresh: () -> Unit,
    onBack: () -> Unit,
    onOpen: (GalleryItem) -> Unit,
) {
    var asGrid by rememberSaveable(title) { mutableStateOf(gridDefault) }
    val firstVideo = items.firstOrNull { it.type == MediaType.VIDEO }
    val summary = "${items.count { it.type == MediaType.VIDEO }} video • ${items.count { it.type == MediaType.IMAGE }} foto"

    PullToRefreshBox(isRefreshing = loading, onRefresh = onRefresh, modifier = Modifier.fillMaxSize()) {
        if (asGrid) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(gridColumns),
                contentPadding = PaddingValues(bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    CollectionHeader(title, summary, items.firstOrNull(), true, firstVideo != null, onBack, { asGrid = false }) { firstVideo?.let(onOpen) }
                }
                gridItems(items, key = { "${it.type}-${it.id}" }) { MediaCell(it) { onOpen(it) } }
            }
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
                item {
                    CollectionHeader(title, summary, items.firstOrNull(), false, firstVideo != null, onBack, { asGrid = true }) { firstVideo?.let(onOpen) }
                }
                items(items, key = { "${it.type}-${it.id}" }) { MediaRow(it) { onOpen(it) } }
            }
        }
    }
}

@Composable
private fun CollectionHeader(
    title: String,
    summary: String,
    cover: GalleryItem?,
    isGrid: Boolean,
    canPlay: Boolean,
    onBack: () -> Unit,
    onToggleView: () -> Unit,
    onPlay: () -> Unit,
) {
    val accent = MaterialTheme.colorScheme.primary
    val bg = MaterialTheme.colorScheme.background
    Column(
        Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(accent.copy(alpha = 0.45f), bg))),
    ) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Kembali") }
        if (cover != null) {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Thumb(cover, 400, Modifier.size(180.dp).clip(RoundedCornerShape(4.dp)))
            }
        }
        Text(title, Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp), fontSize = 26.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Text(summary, Modifier.padding(horizontal = 16.dp), fontSize = 13.sp, color = VSecondary)
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onToggleView) { Icon(if (isGrid) Icons.Filled.Menu else Icons.Filled.GridView, if (isGrid) "Tampilan daftar" else "Tampilan grid") }
            Spacer(Modifier.weight(1f))
            if (canPlay) {
                IconButton(
                    onClick = onPlay,
                    modifier = Modifier.size(56.dp).clip(CircleShape).background(accent),
                ) { Icon(Icons.Filled.PlayArrow, "Putar video pertama", Modifier.size(32.dp), tint = Color.Black) }
            }
        }
    }
}

@Composable
private fun MediaRow(item: GalleryItem, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Thumb(item, 200, Modifier.size(56.dp).clip(RoundedCornerShape(4.dp)))
        Column(Modifier.weight(1f)) {
            Text(item.title(), fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(item.subtitle(), fontSize = 13.sp, color = VSecondary, maxLines = 1)
        }
    }
}

@Composable
private fun MediaCell(item: GalleryItem, onClick: () -> Unit) {
    Box(Modifier.aspectRatio(1f).clickable(onClick = onClick)) {
        Thumb(item, 320, Modifier.fillMaxSize())
        if (item.type == MediaType.VIDEO) {
            Text(
                formatTime(item.durationMs),
                Modifier.align(Alignment.BottomEnd).padding(4.dp).background(Color(0x99000000), RoundedCornerShape(4.dp)).padding(horizontal = 4.dp),
                color = Color.White, fontSize = 11.sp,
            )
        }
    }
}

@Composable
private fun Thumb(item: GalleryItem, sizePx: Int, modifier: Modifier) {
    val context = LocalContext.current
    val bmp by produceState<Bitmap?>(null, item.uri, sizePx) {
        value = ThumbnailLoader.load(context, item.uri, sizePx)
    }
    Box(modifier.background(MaterialTheme.colorScheme.surfaceVariant)) {
        bmp?.let { Image(it.asImageBitmap(), item.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
    }
}

// ---------------- Status kosong / izin ----------------

@Composable
private fun PermissionPrompt(onRequest: () -> Unit, onPickFile: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Izinkan akses ke foto & video", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "vreels hanya membaca media di perangkat ini dan tidak pernah memakai internet. " +
                "Di Android 14 Anda boleh memilih akses penuh atau hanya item tertentu.",
            fontSize = 13.sp, color = VSecondary,
        )
        Spacer(Modifier.height(20.dp))
        Button(onClick = onRequest, shape = CircleShape) { Text("Beri akses", fontWeight = FontWeight.Bold) }
        OutlinedButton(onClick = onPickFile, shape = CircleShape, modifier = Modifier.padding(top = 8.dp)) { Text("Buka satu file video…") }
    }
}

@Composable
private fun EmptyState(onPickFile: () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("Belum ada media", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Tarik ke bawah untuk memindai ulang, atau buka file secara manual.", fontSize = 13.sp, color = VSecondary)
        OutlinedButton(onClick = onPickFile, shape = CircleShape, modifier = Modifier.padding(top = 16.dp)) { Text("Buka file video…") }
    }
}
