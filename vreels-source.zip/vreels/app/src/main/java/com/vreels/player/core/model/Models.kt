package com.vreels.player.core.model

import android.net.Uri

enum class MediaType { VIDEO, IMAGE }
enum class TypeFilter { ALL, VIDEO, PHOTO }
enum class SortOrder { NEWEST, OLDEST, NAME, SIZE, DURATION }

data class GalleryItem(
    val id: Long,
    val uri: Uri,
    val name: String,
    val type: MediaType,
    val sizeBytes: Long,
    val dateAdded: Long,
    val durationMs: Long,
    val bucketId: Long,
    val bucketName: String,
)

data class Folder(
    val id: Long,
    val name: String,
    val count: Int,
    val cover: GalleryItem,
)

enum class MediaAccess { FULL, PARTIAL, DENIED }

/** Satu entri antrean pemutaran (URI dalam bentuk string). */
data class QueueEntry(val uri: String, val name: String)
