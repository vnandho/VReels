package com.vreels.player.feature.player

import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.ui.AspectRatioFrameLayout

enum class AspectMode(val label: String, val resizeMode: Int) {
    FIT("Fit (rasio asli)", AspectRatioFrameLayout.RESIZE_MODE_FIT),
    CROP("Crop / Fill layar", AspectRatioFrameLayout.RESIZE_MODE_ZOOM),
    STRETCH("Stretch", AspectRatioFrameLayout.RESIZE_MODE_FILL),
    FIXED_WIDTH("Lebar penuh", AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH),
    FIXED_HEIGHT("Tinggi penuh", AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT),
}

enum class DialogKind { SPEED, AUDIO, SUBTITLE }
enum class IndicatorKind { BRIGHTNESS, VOLUME }

data class Indicator(val kind: IndicatorKind, val percent: Int, val id: Long)
data class UiMessage(val text: String, val id: Long)

/** State UI player; hanya diubah dari main thread. */
@Stable
class PlayerUiState {
    var playing by mutableStateOf(false)
    var title by mutableStateOf("")
    var index by mutableIntStateOf(0)
    var count by mutableIntStateOf(1)
    var repeatMode by mutableIntStateOf(Player.REPEAT_MODE_OFF)
    var speed by mutableFloatStateOf(1f)
    var aspect by mutableStateOf(AspectMode.FIT)
    var tracks by mutableStateOf(Tracks.EMPTY)
    var controlsVisible by mutableStateOf(true)
    var interactionTick by mutableIntStateOf(0)
    var seeking by mutableStateOf(false)
    var dialog by mutableStateOf<DialogKind?>(null)
    var message by mutableStateOf<UiMessage?>(null)
    var indicator by mutableStateOf<Indicator?>(null)
    var immersive by mutableStateOf(true)

    /** Dipanggil setiap ada interaksi kontrol agar timer auto-hide dimulai ulang. */
    fun interact() { interactionTick++ }
}

interface PlayerActions {
    val player: Player
    fun togglePlay()
    fun seekBy(deltaMs: Long)
    fun seekTo(positionMs: Long)
    fun next()
    fun previous()
    fun cycleRepeat()
    fun rotate()
    fun toggleFullscreen()
    fun cycleAspect()
    fun setSpeed(speed: Float)
    fun pickSubtitle()
    fun selectTrack(type: Int, group: Tracks.Group?, trackIndex: Int)
    fun adjustBrightness(delta: Float)
    fun adjustVolume(delta: Float)
    fun exit()
}
