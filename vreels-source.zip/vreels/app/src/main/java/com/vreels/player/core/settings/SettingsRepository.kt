package com.vreels.player.core.settings

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.preferencesDataStore
import com.vreels.player.core.model.SortOrder
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsStore by preferencesDataStore(name = "reels_settings")

class SettingsRepository(private val context: Context) {
    val flow: Flow<AppSettings> = context.settingsStore.data.map { it.toSettings() }

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        context.settingsStore.edit { p -> p.write(transform(p.toSettings())) }
    }

    suspend fun reset() {
        context.settingsStore.edit { it.clear() }
    }
}

private object K {
    val theme = stringPreferencesKey("theme")
    val accent = intPreferencesKey("accent")
    val grid = intPreferencesKey("grid")
    val sort = stringPreferencesKey("sort")
    val seek = intPreferencesKey("seek_sec")
    val resume = booleanPreferencesKey("resume")
    val decoder = stringPreferencesKey("decoder")
    val qScope = stringPreferencesKey("queue_scope")
    val qBoundary = stringPreferencesKey("queue_boundary")
    val subSize = intPreferencesKey("sub_size")
    val autoHide = intPreferencesKey("auto_hide")
    val iconSize = intPreferencesKey("icon_size")
    val touch = intPreferencesKey("touch")
    val alpha = floatPreferencesKey("panel_alpha")
    val iconStyle = stringPreferencesKey("icon_style")
    val extras = stringPreferencesKey("extras_place")
    val order = stringPreferencesKey("control_order")
    val gBright = booleanPreferencesKey("g_bright")
    val gVol = booleanPreferencesKey("g_vol")
    val gInvert = booleanPreferencesKey("g_invert")
    val gZone = intPreferencesKey("g_zone")
    val gSens = floatPreferencesKey("g_sens")
}

private inline fun <reified E : Enum<E>> Preferences.enumOf(key: Preferences.Key<String>, default: E): E =
    this[key]?.let { runCatching { enumValueOf<E>(it) }.getOrNull() } ?: default

private fun Preferences.toSettings(): AppSettings {
    val d = AppSettings()
    return AppSettings(
        theme = enumOf(K.theme, d.theme),
        accentIndex = this[K.accent] ?: d.accentIndex,
        gridColumns = this[K.grid] ?: d.gridColumns,
        sortOrder = enumOf(K.sort, d.sortOrder),
        seekIntervalSec = this[K.seek] ?: d.seekIntervalSec,
        resumePlayback = this[K.resume] ?: d.resumePlayback,
        decoder = enumOf(K.decoder, d.decoder),
        queueScope = enumOf(K.qScope, d.queueScope),
        queueBoundary = enumOf(K.qBoundary, d.queueBoundary),
        subtitleSizeSp = this[K.subSize] ?: d.subtitleSizeSp,
        autoHideSec = this[K.autoHide] ?: d.autoHideSec,
        iconSizeDp = this[K.iconSize] ?: d.iconSizeDp,
        touchTargetDp = this[K.touch] ?: d.touchTargetDp,
        panelAlpha = this[K.alpha] ?: d.panelAlpha,
        iconStyle = enumOf(K.iconStyle, d.iconStyle),
        extrasPlacement = enumOf(K.extras, d.extrasPlacement),
        controlOrder = this[K.order]?.let { s ->
            s.split(",").filter { it.isNotBlank() }
                .mapNotNull { runCatching { ControlId.valueOf(it) }.getOrNull() }
                .distinct()
        } ?: d.controlOrder,
        gestureBrightness = this[K.gBright] ?: d.gestureBrightness,
        gestureVolume = this[K.gVol] ?: d.gestureVolume,
        invertGestures = this[K.gInvert] ?: d.invertGestures,
        sideZonePercent = this[K.gZone] ?: d.sideZonePercent,
        gestureSensitivity = this[K.gSens] ?: d.gestureSensitivity,
    )
}

private fun MutablePreferences.write(s: AppSettings) {
    this[K.theme] = s.theme.name
    this[K.accent] = s.accentIndex
    this[K.grid] = s.gridColumns
    this[K.sort] = s.sortOrder.name
    this[K.seek] = s.seekIntervalSec
    this[K.resume] = s.resumePlayback
    this[K.decoder] = s.decoder.name
    this[K.qScope] = s.queueScope.name
    this[K.qBoundary] = s.queueBoundary.name
    this[K.subSize] = s.subtitleSizeSp
    this[K.autoHide] = s.autoHideSec
    this[K.iconSize] = s.iconSizeDp
    this[K.touch] = s.touchTargetDp
    this[K.alpha] = s.panelAlpha
    this[K.iconStyle] = s.iconStyle.name
    this[K.extras] = s.extrasPlacement.name
    this[K.order] = s.controlOrder.joinToString(",") { it.name }
    this[K.gBright] = s.gestureBrightness
    this[K.gVol] = s.gestureVolume
    this[K.gInvert] = s.invertGestures
    this[K.gZone] = s.sideZonePercent
    this[K.gSens] = s.gestureSensitivity
}
