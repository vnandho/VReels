@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.vreels.player.feature.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vreels.player.core.design.AccentColors
import com.vreels.player.core.design.PillChip
import com.vreels.player.core.settings.AppSettings
import com.vreels.player.core.settings.ControlId
import com.vreels.player.core.settings.DecoderMode
import com.vreels.player.core.settings.ExtrasPlacement
import com.vreels.player.core.settings.IconStyle
import com.vreels.player.core.settings.QueueBoundary
import com.vreels.player.core.settings.QueueScope
import com.vreels.player.core.settings.SettingsRepository
import com.vreels.player.core.settings.ThemeMode
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(settings: AppSettings, repo: SettingsRepository, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    fun edit(block: (AppSettings) -> AppSettings) { scope.launch { repo.update(block) } }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Pengaturan") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Kembali") } },
        )
    }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {

            Section("Tampilan")
            Choice("Tema", ThemeMode.entries, settings.theme, { when (it) { ThemeMode.DARK -> "Gelap"; ThemeMode.LIGHT -> "Terang"; ThemeMode.SYSTEM -> "Ikuti sistem" } }) { v -> edit { it.copy(theme = v) } }
            Choice("Warna aksen", AccentColors.indices.toList(), settings.accentIndex, { AccentColors[it].first }) { v -> edit { it.copy(accentIndex = v) } }

            Section("Gallery")
            SliderRow("Jumlah kolom grid", settings.gridColumns.toFloat(), 2f..6f, 3, "${settings.gridColumns}") { v -> edit { it.copy(gridColumns = v.roundToInt()) } }
            Choice("Cakupan antrean video", QueueScope.entries, settings.queueScope, { if (it == QueueScope.FOLDER) "Folder saat ini" else "Semua video" }) { v -> edit { it.copy(queueScope = v) } }

            Section("Pemutaran")
            Choice("Interval maju/mundur", listOf(5, 10, 15, 30, 60), settings.seekIntervalSec, { "$it dtk" }) { v -> edit { it.copy(seekIntervalSec = v) } }
            SwitchRow("Lanjutkan dari posisi terakhir", settings.resumePlayback) { v -> edit { it.copy(resumePlayback = v) } }
            Choice("Saat mencapai ujung antrean", QueueBoundary.entries, settings.queueBoundary,
                { when (it) { QueueBoundary.STOP -> "Berhenti"; QueueBoundary.WRAP -> "Ulang dari awal/akhir"; QueueBoundary.MESSAGE -> "Tampilkan pesan" } }) { v -> edit { it.copy(queueBoundary = v) } }
            Choice("Decoder", DecoderMode.entries, settings.decoder,
                { when (it) { DecoderMode.AUTO -> "Otomatis"; DecoderMode.HARDWARE -> "Prioritas hardware"; DecoderMode.SOFTWARE -> "Prioritas software" } }) { v -> edit { it.copy(decoder = v) } }
            Text("Software decoding bisa lebih berat bagi CPU, baterai, dan suhu. Berlaku untuk video berikutnya yang dibuka.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
            SliderRow("Ukuran subtitle", settings.subtitleSizeSp.toFloat(), 12f..36f, 23, "${settings.subtitleSizeSp} sp") { v -> edit { it.copy(subtitleSizeSp = v.roundToInt()) } }

            Section("Gesture")
            SwitchRow("Brightness (sisi kiri)", settings.gestureBrightness) { v -> edit { it.copy(gestureBrightness = v) } }
            SwitchRow("Volume (sisi kanan)", settings.gestureVolume) { v -> edit { it.copy(gestureVolume = v) } }
            SwitchRow("Balik arah gesture", settings.invertGestures) { v -> edit { it.copy(invertGestures = v) } }
            SliderRow("Lebar zona kiri/kanan", settings.sideZonePercent.toFloat(), 15f..45f, 29, "${settings.sideZonePercent}%") { v -> edit { it.copy(sideZonePercent = v.roundToInt()) } }
            SliderRow("Sensitivitas", settings.gestureSensitivity, 0.5f..2f, 14, String.format("%.1f×", settings.gestureSensitivity)) { v -> edit { it.copy(gestureSensitivity = (v * 10).roundToInt() / 10f) } }
            Text("Swipe vertikal di area tengah: ke atas = video berikutnya, ke bawah = sebelumnya. Tap di area kosong hanya menampilkan/menyembunyikan kontrol, tidak pause.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))

            Section("Kontrol Player")
            Choice("Sembunyikan otomatis", listOf(0, 3, 5, 10), settings.autoHideSec, { if (it == 0) "Nonaktif" else "$it dtk" }) { v -> edit { it.copy(autoHideSec = v) } }
            SliderRow("Ukuran ikon", settings.iconSizeDp.toFloat(), 18f..56f, 37, "${settings.iconSizeDp} dp") { v -> edit { it.copy(iconSizeDp = v.roundToInt()) } }
            SliderRow("Ukuran area sentuh", settings.touchTargetDp.toFloat(), 40f..72f, 31, "${settings.touchTargetDp} dp") { v -> edit { it.copy(touchTargetDp = v.roundToInt()) } }
            SliderRow("Transparansi panel", settings.panelAlpha, 0f..0.9f, 17, String.format("%.0f%%", settings.panelAlpha * 100)) { v -> edit { it.copy(panelAlpha = (v * 20).roundToInt() / 20f) } }
            Choice("Gaya ikon", IconStyle.entries, settings.iconStyle, { if (it == IconStyle.OUTLINED) "Outline" else "Filled" }) { v -> edit { it.copy(iconStyle = v) } }
            Choice("Posisi tombol tambahan", ExtrasPlacement.entries, settings.extrasPlacement, { if (it == ExtrasPlacement.BOTTOM) "Bawah" else "Atas" }) { v -> edit { it.copy(extrasPlacement = v) } }

            Text("Tombol (centang = tampil, panah = ubah urutan)", Modifier.padding(top = 12.dp), style = MaterialTheme.typography.titleSmall)
            val ordered = settings.controlOrder + ControlId.entries.filter { it !in settings.controlOrder }
            ordered.forEachIndexed { i, id ->
                val enabled = id in settings.controlOrder
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = enabled, onCheckedChange = { on ->
                        edit { s -> s.copy(controlOrder = if (on) s.controlOrder + id else s.controlOrder - id) }
                    })
                    Text(id.label, Modifier.weight(1f))
                    IconButton(enabled = enabled && settings.controlOrder.indexOf(id) > 0, onClick = {
                        edit { s -> s.copy(controlOrder = s.controlOrder.swap(s.controlOrder.indexOf(id), -1)) }
                    }) { Icon(Icons.Filled.ArrowUpward, "Naikkan ${id.label}") }
                    IconButton(enabled = enabled && settings.controlOrder.indexOf(id) < settings.controlOrder.lastIndex, onClick = {
                        edit { s -> s.copy(controlOrder = s.controlOrder.swap(s.controlOrder.indexOf(id), +1)) }
                    }) { Icon(Icons.Filled.ArrowDownward, "Turunkan ${id.label}") }
                }
            }
            OutlinedButton(onClick = { scope.launch { repo.reset() } }, Modifier.padding(vertical = 16.dp)) { Text("Reset semua ke default") }

            Section("Privasi")
            Text(
                "vreels tidak memiliki izin internet, iklan, analytics, atau pelacak. Media dan pengaturan hanya diproses di perangkat ini.",
                fontSize = 13.sp,
            )
            Section("Tentang")
            Text("vreels 1.0.0 · Pemutar memakai AndroidX Media3 (Apache License 2.0). Lihat folder LICENSES pada source project.", fontSize = 13.sp)
            Text("", Modifier.padding(24.dp))
        }
    }
}

private fun <T> List<T>.swap(index: Int, offset: Int): List<T> {
    val j = index + offset
    if (index !in indices || j !in indices) return this
    return toMutableList().also { val t = it[index]; it[index] = it[j]; it[j] = t }
}

@Composable
private fun Section(title: String) {
    HorizontalDivider(Modifier.padding(top = 16.dp))
    Text(title, Modifier.padding(top = 12.dp, bottom = 4.dp), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, steps: Int, valueText: String, onChange: (Float) -> Unit) {
    Column(Modifier.padding(vertical = 2.dp)) {
        Row {
            Text(label, Modifier.weight(1f))
            Text(valueText, color = MaterialTheme.colorScheme.primary)
        }
        Slider(value = value.coerceIn(range), onValueChange = onChange, valueRange = range, steps = steps)
    }
}

@Composable
private fun <T> Choice(label: String, options: List<T>, selected: T, labelOf: (T) -> String, onSelect: (T) -> Unit) {
    Column(Modifier.padding(vertical = 4.dp)) {
        Text(label)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { o ->
                PillChip(selected = o == selected, onClick = { onSelect(o) }, label = labelOf(o))
            }
        }
    }
}
