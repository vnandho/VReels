@file:OptIn(UnstableApi::class)

package com.vreels.player.feature.player

import android.util.TypedValue
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.BrightnessMedium
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.outlined.Audiotrack as OAudiotrack
import androidx.compose.material.icons.outlined.AspectRatio as OAspectRatio
import androidx.compose.material.icons.outlined.FastForward as OFastForward
import androidx.compose.material.icons.outlined.FastRewind as OFastRewind
import androidx.compose.material.icons.outlined.Fullscreen as OFullscreen
import androidx.compose.material.icons.outlined.FullscreenExit as OFullscreenExit
import androidx.compose.material.icons.outlined.Pause as OPause
import androidx.compose.material.icons.outlined.PlayArrow as OPlayArrow
import androidx.compose.material.icons.outlined.Repeat as ORepeat
import androidx.compose.material.icons.outlined.RepeatOne as ORepeatOne
import androidx.compose.material.icons.outlined.ScreenRotation as OScreenRotation
import androidx.compose.material.icons.outlined.SkipNext as OSkipNext
import androidx.compose.material.icons.outlined.SkipPrevious as OSkipPrevious
import androidx.compose.material.icons.outlined.Speed as OSpeed
import androidx.compose.material.icons.outlined.Subtitles as OSubtitles
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.IconButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.changedToUp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.PlayerView
import com.vreels.player.core.common.formatTime
import com.vreels.player.core.settings.AppSettings
import com.vreels.player.core.settings.CenterControls
import com.vreels.player.core.settings.ControlId
import com.vreels.player.core.settings.ExtrasPlacement
import com.vreels.player.core.settings.IconStyle
import com.vreels.player.playback.gestures.GestureClassifier
import com.vreels.player.playback.gestures.GestureConfig
import com.vreels.player.playback.gestures.GestureEvent
import kotlinx.coroutines.delay
import java.util.Locale

@Composable
fun PlayerScreen(player: Player, state: PlayerUiState, settings: AppSettings, actions: PlayerActions) {
    var size by remember { mutableStateOf(IntSize.Zero) }

    // Auto-hide: tidak berjalan saat menggeser timeline atau dialog terbuka.
    LaunchedEffect(state.controlsVisible, state.interactionTick, state.seeking, state.dialog) {
        if (state.controlsVisible && settings.autoHideSec > 0 && !state.seeking && state.dialog == null) {
            delay(settings.autoHideSec * 1000L)
            state.controlsVisible = false
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black).onSizeChanged { size = it }) {
        // Layer 1: video
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                PlayerView(ctx).apply {
                    useController = false
                    this.player = player
                    subtitleView?.setApplyEmbeddedFontSizes(false)
                }
            },
            update = { view ->
                view.resizeMode = state.aspect.resizeMode
                view.subtitleView?.setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, settings.subtitleSizeSp.toFloat())
            },
        )

        // Layer 2: gesture surface. Berada DI BAWAH kontrol, jadi tombol/timeline selalu menang.
        Box(
            Modifier.fillMaxSize().pointerInput(settings, size) {
                val classifier = GestureClassifier(
                    GestureConfig(
                        brightnessEnabled = settings.gestureBrightness,
                        volumeEnabled = settings.gestureVolume,
                        invert = settings.invertGestures,
                        sideZoneFraction = settings.sideZonePercent / 100f,
                        sensitivity = settings.gestureSensitivity,
                        touchSlopPx = viewConfiguration.touchSlop * 1.5f,
                        navThresholdPx = maxOf(96.dp.toPx(), size.height * 0.12f),
                    ),
                    size.width.toFloat(), size.height.toFloat(),
                )
                fun handle(e: GestureEvent) {
                    when (e) {
                        GestureEvent.None -> Unit
                        GestureEvent.Tap -> { // hanya toggle kontrol, TIDAK pause/play
                            state.controlsVisible = !state.controlsVisible
                            state.interact()
                        }
                        is GestureEvent.Brightness -> actions.adjustBrightness(e.delta)
                        is GestureEvent.Volume -> actions.adjustVolume(e.delta)
                        GestureEvent.Next -> actions.next()
                        GestureEvent.Previous -> actions.previous()
                    }
                }
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    classifier.onDown(down.position.x, down.position.y)
                    var cancelled = false
                    while (true) {
                        val ev = awaitPointerEvent()
                        val ch = ev.changes.firstOrNull { it.id == down.id }
                        if (ch == null) { classifier.cancel(); break }
                        if (ev.changes.size > 1 && !cancelled) { classifier.cancel(); cancelled = true }
                        if (ch.changedToUp()) {
                            if (!cancelled) handle(classifier.onUp(ch.position.x, ch.position.y))
                            break
                        }
                        if (!cancelled) {
                            handle(classifier.onMove(ch.position.x, ch.position.y))
                            ch.consume()
                        }
                    }
                }
            },
        )

        // Layer 3: kontrol (hanya elemen interaktifnya yang menangkap sentuhan)
        AnimatedVisibility(state.controlsVisible, enter = fadeIn(), exit = fadeOut()) {
            Controls(player, state, settings, actions)
        }

        IndicatorOverlay(state)
        MessageOverlay(state)
        Dialogs(state, actions)
    }
}

// ---------------- Controls ----------------

@Composable
private fun Controls(player: Player, state: PlayerUiState, settings: AppSettings, actions: PlayerActions) {
    val enabled = settings.controlOrder
    val center = enabled.filter { it in CenterControls }
    val extras = enabled.filter { it !in CenterControls && it != ControlId.TIMELINE }
    val showTimeline = ControlId.TIMELINE in enabled
    val top = Brush.verticalGradient(listOf(Color.Black.copy(alpha = settings.panelAlpha), Color.Transparent))
    val bottom = Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = settings.panelAlpha)))

    Box(Modifier.fillMaxSize().safeDrawingPadding()) {
        Column(Modifier.align(Alignment.TopCenter).fillMaxWidth().background(top)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { actions.exit() }, modifier = Modifier.size(settings.touchTargetDp.dp)) {
                    Icon(Icons.Filled.KeyboardArrowDown, "Kembali ke gallery", Modifier.size((settings.iconSizeDp * 1.2f).dp), tint = Color.White)
                }
                Text(state.title, Modifier.weight(1f), color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (state.count > 1) Text("${state.index + 1}/${state.count}", color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(end = 12.dp))
            }
            if (settings.extrasPlacement == ExtrasPlacement.TOP) ExtrasRow(extras, state, settings, actions)
        }

        if (center.isNotEmpty()) {
            Row(Modifier.align(Alignment.Center), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                center.forEach { ControlButton(it, state, settings, actions) }
            }
        }

        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(bottom)) {
            if (showTimeline) Timeline(player, state, settings)
            if (settings.extrasPlacement == ExtrasPlacement.BOTTOM) ExtrasRow(extras, state, settings, actions)
        }
    }
}

@Composable
private fun ExtrasRow(extras: List<ControlId>, state: PlayerUiState, settings: AppSettings, actions: PlayerActions) {
    if (extras.isEmpty()) return
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) { extras.forEach { ControlButton(it, state, settings, actions) } }
}

private inline fun pick(filled: Boolean, f: () -> ImageVector, o: () -> ImageVector) = if (filled) f() else o()

@Composable
private fun ControlButton(id: ControlId, state: PlayerUiState, settings: AppSettings, actions: PlayerActions) {
    val filled = settings.iconStyle == IconStyle.FILLED
    val interval = settings.seekIntervalSec
    val isCenterPlay = id == ControlId.PLAY_PAUSE
    var tint = Color.White

    val icon: ImageVector
    val desc: String
    val onClick: () -> Unit
    when (id) {
        ControlId.PREVIOUS -> { icon = pick(filled, { Icons.Filled.SkipPrevious }, { Icons.Outlined.OSkipPrevious }); desc = "Video sebelumnya"; onClick = actions::previous }
        ControlId.BACKWARD -> { icon = pick(filled, { Icons.Filled.FastRewind }, { Icons.Outlined.OFastRewind }); desc = "Mundur $interval detik"; onClick = { actions.seekBy(-interval * 1000L) } }
        ControlId.PLAY_PAUSE -> {
            icon = if (state.playing) pick(filled, { Icons.Filled.Pause }, { Icons.Outlined.OPause }) else pick(filled, { Icons.Filled.PlayArrow }, { Icons.Outlined.OPlayArrow })
            desc = if (state.playing) "Pause" else "Play"; onClick = actions::togglePlay
        }
        ControlId.FORWARD -> { icon = pick(filled, { Icons.Filled.FastForward }, { Icons.Outlined.OFastForward }); desc = "Maju $interval detik"; onClick = { actions.seekBy(interval * 1000L) } }
        ControlId.NEXT -> { icon = pick(filled, { Icons.Filled.SkipNext }, { Icons.Outlined.OSkipNext }); desc = "Video berikutnya"; onClick = actions::next }
        ControlId.REPEAT -> {
            icon = if (state.repeatMode == Player.REPEAT_MODE_ONE) pick(filled, { Icons.Filled.RepeatOne }, { Icons.Outlined.ORepeatOne })
            else pick(filled, { Icons.Filled.Repeat }, { Icons.Outlined.ORepeat })
            if (state.repeatMode == Player.REPEAT_MODE_OFF) tint = Color(0x99FFFFFF)
            desc = when (state.repeatMode) { Player.REPEAT_MODE_ONE -> "Repeat satu video"; Player.REPEAT_MODE_ALL -> "Repeat semua"; else -> "Repeat mati" }
            onClick = actions::cycleRepeat
        }
        ControlId.ROTATE -> { icon = pick(filled, { Icons.Filled.ScreenRotation }, { Icons.Outlined.OScreenRotation }); desc = "Rotasi layar"; onClick = actions::rotate }
        ControlId.FULLSCREEN -> {
            icon = if (state.immersive) pick(filled, { Icons.Filled.FullscreenExit }, { Icons.Outlined.OFullscreenExit }) else pick(filled, { Icons.Filled.Fullscreen }, { Icons.Outlined.OFullscreen })
            desc = if (state.immersive) "Keluar fullscreen" else "Fullscreen"; onClick = actions::toggleFullscreen
        }
        ControlId.SUBTITLE -> { icon = pick(filled, { Icons.Filled.Subtitles }, { Icons.Outlined.OSubtitles }); desc = "Subtitle"; onClick = { state.dialog = DialogKind.SUBTITLE } }
        ControlId.AUDIO_TRACK -> { icon = pick(filled, { Icons.Filled.Audiotrack }, { Icons.Outlined.OAudiotrack }); desc = "Audio track"; onClick = { state.dialog = DialogKind.AUDIO } }
        ControlId.SPEED -> { icon = pick(filled, { Icons.Filled.Speed }, { Icons.Outlined.OSpeed }); desc = "Kecepatan ${state.speed}×"; onClick = { state.dialog = DialogKind.SPEED } }
        ControlId.ASPECT -> { icon = pick(filled, { Icons.Filled.AspectRatio }, { Icons.Outlined.OAspectRatio }); desc = "Aspect ratio: ${state.aspect.label}"; onClick = actions::cycleAspect }
        ControlId.TIMELINE -> return
    }
    val target = settings.touchTargetDp.dp * (if (isCenterPlay) 1.3f else 1f)
    val iconSize = settings.iconSizeDp.dp * (if (isCenterPlay) 1.3f else 1f)
    if (isCenterPlay) {
        IconButton(
            onClick = { onClick(); state.interact() },
            modifier = Modifier.size(target),
            colors = IconButtonDefaults.iconButtonColors(containerColor = Color.White, contentColor = Color.Black),
        ) { Icon(icon, desc, Modifier.size(iconSize), tint = Color.Black) }
    } else {
        IconButton(onClick = { onClick(); state.interact() }, modifier = Modifier.size(target)) {
            Icon(icon, desc, Modifier.size(iconSize), tint = tint)
        }
    }
}

// ---------------- Timeline ----------------

@Composable
private fun Timeline(player: Player, state: PlayerUiState, settings: AppSettings) {
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var dragging by remember { mutableStateOf(false) }
    var dragFraction by remember { mutableFloatStateOf(0f) }

    // Polling di composable kecil ini saja, agar bagian UI lain tidak ikut recompose.
    LaunchedEffect(player) {
        while (true) {
            if (!dragging) {
                position = player.currentPosition
                duration = player.duration.takeIf { it != C.TIME_UNSET }?.coerceAtLeast(0L) ?: 0L
            }
            delay(250)
        }
    }
    val fraction = if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f
    val shownFraction = if (dragging) dragFraction else fraction
    val shownPosition = if (dragging) (dragFraction * duration).toLong() else position

    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(formatTime(shownPosition), color = Color.White, fontSize = 12.sp)
        Slider(
            value = shownFraction,
            onValueChange = { dragging = true; state.seeking = true; dragFraction = it },
            onValueChangeFinished = {
                player.seekTo((dragFraction * duration).toLong())
                dragging = false; state.seeking = false; state.interact()
            },
            colors = SliderDefaults.colors(
                thumbColor = Color.White, activeTrackColor = Color.White, inactiveTrackColor = Color(0x4DFFFFFF),
            ),
            modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
        )
        Text(formatTime(duration), color = Color.White, fontSize = 12.sp)
    }
}

// ---------------- Overlays & dialogs ----------------

@Composable
private fun IndicatorOverlay(state: PlayerUiState) {
    val ind = state.indicator ?: return
    LaunchedEffect(ind.id) {
        delay(900)
        if (state.indicator?.id == ind.id) state.indicator = null
    }
    Box(Modifier.fillMaxSize().safeDrawingPadding(), contentAlignment = Alignment.TopCenter) {
        Row(
            Modifier.padding(top = 56.dp).clip(RoundedCornerShape(20.dp)).background(Color(0xB3000000)).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(if (ind.kind == IndicatorKind.BRIGHTNESS) Icons.Filled.BrightnessMedium else Icons.AutoMirrored.Filled.VolumeUp,
                if (ind.kind == IndicatorKind.BRIGHTNESS) "Brightness" else "Volume", tint = Color.White)
            Text("  ${ind.percent}%", color = Color.White)
        }
    }
}

@Composable
private fun MessageOverlay(state: PlayerUiState) {
    val msg = state.message ?: return
    LaunchedEffect(msg.id) {
        delay(1800)
        if (state.message?.id == msg.id) state.message = null
    }
    Box(Modifier.fillMaxSize().safeDrawingPadding(), contentAlignment = Alignment.Center) {
        Text(
            msg.text, color = Color.White, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 32.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xB3000000)).padding(horizontal = 16.dp, vertical = 10.dp),
        )
    }
}

@Composable
private fun Dialogs(state: PlayerUiState, actions: PlayerActions) {
    when (state.dialog) {
        null -> Unit
        DialogKind.SPEED -> {
            val speeds = listOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f, 3f, 4f)
            ChoiceDialog("Kecepatan putar", speeds.map { "${it}×" }, speeds.indexOfFirst { it == state.speed },
                onSelect = { actions.setSpeed(speeds[it]); state.dialog = null }, onDismiss = { state.dialog = null })
        }
        DialogKind.AUDIO -> {
            val entries = trackEntries(state, C.TRACK_TYPE_AUDIO)
            if (entries.isEmpty()) ChoiceDialog("Audio track", emptyList(), -1, {}, { state.dialog = null }) { Text("Tidak ada track audio yang bisa dipilih.") }
            else ChoiceDialog("Audio track", entries.map { it.label }, entries.indexOfFirst { it.selected },
                onSelect = { i -> val e = entries[i]; actions.selectTrack(C.TRACK_TYPE_AUDIO, e.group, e.index); state.dialog = null },
                onDismiss = { state.dialog = null })
        }
        DialogKind.SUBTITLE -> {
            val entries = trackEntries(state, C.TRACK_TYPE_TEXT)
            val anySelected = entries.any { it.selected }
            val labels = listOf("Mati") + entries.map { it.label }
            ChoiceDialog("Subtitle", labels, if (anySelected) entries.indexOfFirst { it.selected } + 1 else 0,
                onSelect = { i ->
                    if (i == 0) actions.selectTrack(C.TRACK_TYPE_TEXT, null, 0)
                    else entries[i - 1].let { actions.selectTrack(C.TRACK_TYPE_TEXT, it.group, it.index) }
                    state.dialog = null
                },
                onDismiss = { state.dialog = null },
            ) {
                TextButton(onClick = { state.dialog = null; actions.pickSubtitle() }) { Text("Muat file subtitle (.srt / .ass / .vtt)…") }
            }
        }
    }
}

private data class TrackEntry(val group: androidx.media3.common.Tracks.Group, val index: Int, val label: String, val selected: Boolean)

private fun trackEntries(state: PlayerUiState, type: Int): List<TrackEntry> {
    val out = mutableListOf<TrackEntry>()
    state.tracks.groups.filter { it.type == type }.forEach { g ->
        for (i in 0 until g.length) {
            if (!g.isTrackSupported(i)) continue
            out += TrackEntry(g, i, trackLabel(g.getTrackFormat(i), i, type), g.isTrackSelected(i))
        }
    }
    return out
}

private fun trackLabel(f: Format, i: Int, type: Int): String {
    val lang = f.language?.takeIf { it != "und" }?.let { Locale.forLanguageTag(it).displayLanguage }?.takeIf { it.isNotBlank() }
    val channels = if (type == C.TRACK_TYPE_AUDIO && f.channelCount > 0) "${f.channelCount}ch" else null
    return listOfNotNull(f.label, lang, channels).joinToString(" · ").ifBlank { "Track ${i + 1}" }
}

@Composable
private fun ChoiceDialog(
    title: String,
    options: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit,
    onDismiss: () -> Unit,
    extra: @Composable () -> Unit = {},
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Tutup") } },
        title = { Text(title) },
        text = {
            Column {
                extra()
                LazyColumn {
                    itemsIndexed(options) { i, label ->
                        Row(Modifier.fillMaxWidth().clickable { onSelect(i) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = i == selected, onClick = null)
                            Text(label, Modifier.padding(start = 12.dp))
                        }
                    }
                }
            }
        },
    )
}
