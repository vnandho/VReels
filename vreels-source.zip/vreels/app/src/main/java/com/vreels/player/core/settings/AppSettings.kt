package com.vreels.player.core.settings

import com.vreels.player.core.model.SortOrder

enum class ThemeMode { DARK, LIGHT, SYSTEM }
enum class QueueScope { FOLDER, ALL }
enum class QueueBoundary { STOP, WRAP, MESSAGE }
enum class DecoderMode { AUTO, HARDWARE, SOFTWARE }
enum class IconStyle { OUTLINED, FILLED }
enum class ExtrasPlacement { BOTTOM, TOP }

enum class ControlId(val label: String) {
    PREVIOUS("Video sebelumnya"),
    BACKWARD("Mundur"),
    PLAY_PAUSE("Play / Pause"),
    FORWARD("Maju"),
    NEXT("Video berikutnya"),
    REPEAT("Repeat"),
    ROTATE("Rotasi layar"),
    FULLSCREEN("Fullscreen"),
    SUBTITLE("Subtitle"),
    AUDIO_TRACK("Audio track"),
    SPEED("Kecepatan"),
    ASPECT("Aspect ratio"),
    TIMELINE("Timeline"),
}

/** Tombol yang tampil di kelompok tengah layar. */
val CenterControls = setOf(
    ControlId.PREVIOUS, ControlId.BACKWARD, ControlId.PLAY_PAUSE, ControlId.FORWARD, ControlId.NEXT,
)

data class AppSettings(
    // Appearance
    val theme: ThemeMode = ThemeMode.DARK,
    val accentIndex: Int = 0,
    // Gallery
    val gridColumns: Int = 3,
    val sortOrder: SortOrder = SortOrder.NEWEST,
    // Playback
    val seekIntervalSec: Int = 10,
    val resumePlayback: Boolean = true,
    val decoder: DecoderMode = DecoderMode.AUTO,
    val queueScope: QueueScope = QueueScope.FOLDER,
    val queueBoundary: QueueBoundary = QueueBoundary.STOP,
    val subtitleSizeSp: Int = 18,
    // Player controls
    val autoHideSec: Int = 3, // 0 = nonaktif
    val iconSizeDp: Int = 32,
    val touchTargetDp: Int = 48,
    val panelAlpha: Float = 0.45f,
    val iconStyle: IconStyle = IconStyle.OUTLINED,
    val extrasPlacement: ExtrasPlacement = ExtrasPlacement.BOTTOM,
    /** Hanya tombol yang AKTIF, sesuai urutan tampil. */
    val controlOrder: List<ControlId> = ControlId.entries.toList(),
    // Gestures
    val gestureBrightness: Boolean = true,
    val gestureVolume: Boolean = true,
    val invertGestures: Boolean = false,
    val sideZonePercent: Int = 28,
    val gestureSensitivity: Float = 1.0f,
)
