package com.vreels.player.playback.gestures

import kotlin.math.abs
import kotlin.math.hypot

enum class Zone { LEFT, CENTER, RIGHT }

data class GestureConfig(
    val brightnessEnabled: Boolean = true,
    val volumeEnabled: Boolean = true,
    val invert: Boolean = false,
    /** Lebar zona kiri dan kanan, masing-masing, sebagai pecahan lebar layar (0.1..0.45). */
    val sideZoneFraction: Float = 0.28f,
    val sensitivity: Float = 1.0f,
    val touchSlopPx: Float = 24f,
    /** Swipe vertikal harus minimal sekian kali lebih besar dari gerak horizontal. */
    val directionRatio: Float = 1.3f,
    /** Jarak vertikal minimum agar swipe tengah dihitung sebagai Next/Previous. */
    val navThresholdPx: Float = 160f,
)

sealed interface GestureEvent {
    data object None : GestureEvent
    data object Tap : GestureEvent
    /** [delta] dalam pecahan 0..1 dari rentang penuh; positif = naik. */
    data class Brightness(val delta: Float) : GestureEvent
    data class Volume(val delta: Float) : GestureEvent
    data object Next : GestureEvent
    data object Previous : GestureEvent
}

/**
 * State machine gesture murni (tanpa dependensi Android) sehingga bisa diuji unit.
 *
 * Aturan:
 * - Zona ditentukan dari posisi saat sentuhan awal, bukan posisi jari setelah bergerak.
 * - Di bawah touch slop => tap, bukan swipe.
 * - Vertikal sah hanya jika |dy| >= directionRatio * |dx|.
 * - Kiri = brightness, kanan = volume, tengah = next/previous (dieksekusi saat jari diangkat).
 * - Tombol dan timeline berada di layer lain di atas surface ini, jadi tidak pernah sampai ke sini.
 */
class GestureClassifier(
    private val config: GestureConfig,
    private val widthPx: Float,
    private val heightPx: Float,
) {
    private enum class Mode { IDLE, PENDING, BRIGHTNESS, VOLUME, NAVIGATE, REJECTED }

    private var mode = Mode.IDLE
    private var startX = 0f
    private var startY = 0f
    private var lastY = 0f
    private var zone = Zone.CENTER

    fun zoneAt(x: Float): Zone {
        val side = widthPx * config.sideZoneFraction
        return when {
            x < side -> Zone.LEFT
            x > widthPx - side -> Zone.RIGHT
            else -> Zone.CENTER
        }
    }

    fun onDown(x: Float, y: Float) {
        startX = x; startY = y; lastY = y
        zone = zoneAt(x)
        mode = Mode.PENDING
    }

    fun onMove(x: Float, y: Float): GestureEvent {
        return when (mode) {
            Mode.IDLE, Mode.REJECTED, Mode.NAVIGATE -> GestureEvent.None
            Mode.PENDING -> {
                val dx = x - startX
                val dy = y - startY
                if (hypot(dx, dy) < config.touchSlopPx) {
                    GestureEvent.None
                } else if (abs(dy) < config.directionRatio * abs(dx)) {
                    mode = Mode.REJECTED
                    GestureEvent.None
                } else {
                    mode = when (zone) {
                        Zone.LEFT -> if (config.brightnessEnabled) Mode.BRIGHTNESS else Mode.REJECTED
                        Zone.RIGHT -> if (config.volumeEnabled) Mode.VOLUME else Mode.REJECTED
                        Zone.CENTER -> Mode.NAVIGATE
                    }
                    lastY = y
                    GestureEvent.None
                }
            }
            Mode.BRIGHTNESS, Mode.VOLUME -> {
                val sign = if (config.invert) -1f else 1f
                val delta = (lastY - y) / heightPx * config.sensitivity * sign
                lastY = y
                if (delta == 0f) GestureEvent.None
                else if (mode == Mode.BRIGHTNESS) GestureEvent.Brightness(delta)
                else GestureEvent.Volume(delta)
            }
        }
    }

    fun onUp(x: Float, y: Float): GestureEvent {
        val result = when (mode) {
            Mode.PENDING -> GestureEvent.Tap
            Mode.NAVIGATE -> {
                val dx = x - startX
                val dy = y - startY
                if (abs(dy) >= config.navThresholdPx && abs(dy) >= config.directionRatio * abs(dx)) {
                    // Swipe ke atas (y mengecil) = video berikutnya.
                    if (dy < 0) GestureEvent.Next else GestureEvent.Previous
                } else GestureEvent.None
            }
            else -> GestureEvent.None
        }
        mode = Mode.IDLE
        return result
    }

    fun cancel() {
        mode = Mode.IDLE
    }
}
