package com.vreels.player.core.common

import android.content.Context

/** Menyimpan posisi terakhir per video, hanya di perangkat (SharedPreferences privat). */
class ResumeStore(context: Context) {
    private val prefs = context.getSharedPreferences("resume_positions", Context.MODE_PRIVATE)

    fun get(key: String): Long = prefs.getLong(key, 0L)

    fun save(key: String, positionMs: Long, durationMs: Long) {
        val nearEnd = durationMs > 0 && positionMs >= durationMs - 5_000
        if (positionMs < 5_000 || nearEnd) prefs.edit().remove(key).apply()
        else prefs.edit().putLong(key, positionMs).apply()
    }
}
