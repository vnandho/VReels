@file:OptIn(UnstableApi::class)

package com.vreels.player.feature.player

import android.content.Context
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.exoplayer.mediacodec.MediaCodecUtil
import com.vreels.player.core.common.ResumeStore
import com.vreels.player.core.design.ReelsTheme
import com.vreels.player.core.model.QueueEntry
import com.vreels.player.core.settings.AppSettings
import com.vreels.player.core.settings.DecoderMode
import com.vreels.player.core.settings.SettingsRepository
import com.vreels.player.playback.queue.PlaybackQueueStore
import com.vreels.player.playback.queue.QueueNavigator
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlin.math.roundToInt

class PlayerActivity : ComponentActivity(), PlayerActions {

    companion object {
        const val EXTRA_INDEX = "queue_index"
    }

    private lateinit var settings: AppSettings
    private lateinit var resumeStore: ResumeStore
    private lateinit var audioManager: AudioManager
    private lateinit var queue: List<QueueEntry>
    private val state = PlayerUiState()
    private var exo: ExoPlayer? = null
    override val player: Player get() = exo!!

    private var brightness = 0.5f
    private var volumeLevel = 0.5f
    private var orientationStep = 0
    private var wasPlayingBeforeStop = false
    private var messageCounter = 0L
    private var firstItemShown = false

    private val pickSubtitle = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) loadExternalSubtitle(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = runBlocking { SettingsRepository(applicationContext).flow.first() }
        resumeStore = ResumeStore(applicationContext)
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager

        val startIndex: Int
        val stored = PlaybackQueueStore.items
        if (intent.hasExtra(EXTRA_INDEX) && stored.isNotEmpty()) {
            queue = stored
            startIndex = intent.getIntExtra(EXTRA_INDEX, 0).coerceIn(0, stored.lastIndex)
        } else if (intent.data != null) {
            val uri = intent.data!!
            queue = listOf(QueueEntry(uri.toString(), displayName(uri)))
            startIndex = 0
        } else {
            finish(); return
        }

        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.attributes = window.attributes.apply {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        applyImmersive(true)
        initBrightnessAndVolume()

        val p = buildPlayer()
        exo = p
        p.setMediaItems(queue.map(::toMediaItem), startIndex, startPositionFor(startIndex))
        p.prepare()
        p.playWhenReady = true
        state.count = queue.size
        state.index = startIndex
        state.title = queue[startIndex].name

        setContent {
            ReelsTheme(settings.theme, settings.accentIndex) {
                PlayerScreen(p, state, settings, this)
            }
        }
    }

    // ---------- Player setup ----------

    private fun buildPlayer(): ExoPlayer {
        val selector = when (settings.decoder) {
            DecoderMode.AUTO -> MediaCodecSelector.DEFAULT
            DecoderMode.HARDWARE -> MediaCodecSelector { mime, secure, tunneling ->
                val all = MediaCodecUtil.getDecoderInfos(mime, secure, tunneling)
                all.filter { it.hardwareAccelerated }.ifEmpty { all }
            }
            DecoderMode.SOFTWARE -> MediaCodecSelector { mime, secure, tunneling ->
                val all = MediaCodecUtil.getDecoderInfos(mime, secure, tunneling)
                all.filter { it.softwareOnly }.ifEmpty { all }
            }
        }
        val renderers = DefaultRenderersFactory(this)
            .setMediaCodecSelector(selector)
            .setEnableDecoderFallback(true)
        return ExoPlayer.Builder(this, renderers)
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(),
                /* handleAudioFocus = */ true,
            )
            .setHandleAudioBecomingNoisy(true)
            .setSeekBackIncrementMs(settings.seekIntervalSec * 1000L)
            .setSeekForwardIncrementMs(settings.seekIntervalSec * 1000L)
            .build()
            .also { it.addListener(listener) }
    }

    private val listener = object : Player.Listener {
        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) = syncPlaying()
        override fun onPlaybackStateChanged(playbackState: Int) = syncPlaying()
        override fun onRepeatModeChanged(repeatMode: Int) { state.repeatMode = repeatMode }
        override fun onTracksChanged(tracks: Tracks) { state.tracks = tracks }
        override fun onPlaybackParametersChanged(playbackParameters: androidx.media3.common.PlaybackParameters) {
            state.speed = playbackParameters.speed
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val p = exo ?: return
            state.index = p.currentMediaItemIndex
            state.title = mediaItem?.mediaMetadata?.title?.toString().orEmpty()
            if (firstItemShown) showMessage("${state.index + 1}/${state.count} · ${state.title}")
            firstItemShown = true
        }

        override fun onPlayerError(error: PlaybackException) {
            showMessage("Tidak dapat memutar video ini (${error.errorCodeName}). Format/codec mungkin tidak didukung perangkat.")
        }
    }

    private fun syncPlaying() {
        val p = exo ?: return
        state.playing = p.playWhenReady && p.playbackState != Player.STATE_ENDED
    }

    private fun toMediaItem(e: QueueEntry): MediaItem =
        MediaItem.Builder()
            .setUri(Uri.parse(e.uri))
            .setMediaId(e.uri)
            .setMediaMetadata(MediaMetadata.Builder().setTitle(e.name).build())
            .build()

    private fun startPositionFor(index: Int): Long =
        if (settings.resumePlayback) resumeStore.get(queue[index].uri) else 0L

    private fun displayName(uri: Uri): String =
        runCatching {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            }
        }.getOrNull() ?: uri.lastPathSegment ?: "Video"

    private fun saveResume() {
        val p = exo ?: return
        val id = p.currentMediaItem?.mediaId ?: return
        resumeStore.save(id, p.currentPosition, p.duration.coerceAtLeast(0))
    }

    private fun showMessage(text: String) {
        state.message = UiMessage(text, ++messageCounter)
    }

    // ---------- Brightness / volume ----------

    private fun initBrightnessAndVolume() {
        val current = window.attributes.screenBrightness
        brightness = if (current >= 0f) current else runCatching {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
        }.getOrDefault(0.5f)
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        volumeLevel = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC) / max.toFloat()
    }

    override fun adjustBrightness(delta: Float) {
        brightness = (brightness + delta).coerceIn(0.01f, 1f)
        // Hanya mengubah brightness jendela player ini, bukan pengaturan sistem.
        window.attributes = window.attributes.apply { screenBrightness = brightness }
        state.indicator = Indicator(IndicatorKind.BRIGHTNESS, (brightness * 100).roundToInt(), ++messageCounter)
    }

    override fun adjustVolume(delta: Float) {
        volumeLevel = (volumeLevel + delta).coerceIn(0f, 1f)
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, (volumeLevel * max).roundToInt(), 0)
        state.indicator = Indicator(IndicatorKind.VOLUME, (volumeLevel * 100).roundToInt(), ++messageCounter)
    }

    // ---------- PlayerActions ----------

    override fun togglePlay() {
        val p = exo ?: return
        if (p.playbackState == Player.STATE_ENDED) { p.seekTo(0); p.playWhenReady = true }
        else p.playWhenReady = !p.playWhenReady
    }

    override fun seekBy(deltaMs: Long) {
        val p = exo ?: return
        val target = (p.currentPosition + deltaMs).coerceAtLeast(0)
        val dur = p.duration
        p.seekTo(if (dur != C.TIME_UNSET) target.coerceAtMost(dur) else target)
    }

    override fun seekTo(positionMs: Long) { exo?.seekTo(positionMs) }

    override fun next() = navigate(forward = true)
    override fun previous() = navigate(forward = false)

    private fun navigate(forward: Boolean) {
        val p = exo ?: return
        val r = QueueNavigator.target(p.currentMediaItemIndex, p.mediaItemCount, forward, settings.queueBoundary)
        val target = r.index
        if (target != null) {
            saveResume()
            p.seekTo(target, startPositionFor(target)) // autoplay: playWhenReady tetap aktif
            p.playWhenReady = true
        } else if (r.showMessage) {
            showMessage(if (forward) "Ini video terakhir" else "Ini video pertama")
        }
    }

    override fun cycleRepeat() {
        val p = exo ?: return
        val (mode, label) = when (p.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ONE to "Ulangi video ini"
            Player.REPEAT_MODE_ONE -> Player.REPEAT_MODE_ALL to "Ulangi semua"
            else -> Player.REPEAT_MODE_OFF to "Repeat mati"
        }
        p.repeatMode = mode
        showMessage(label)
    }

    override fun rotate() {
        orientationStep = (orientationStep + 1) % 3
        val (mode, label) = when (orientationStep) {
            1 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE to "Kunci landscape"
            2 -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT to "Kunci portrait"
            else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED to "Rotasi otomatis"
        }
        requestedOrientation = mode
        showMessage(label)
    }

    override fun toggleFullscreen() {
        state.immersive = !state.immersive
        applyImmersive(state.immersive)
    }

    private fun applyImmersive(on: Boolean) {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        if (on) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && state.immersive) applyImmersive(true) // pulih setelah notifikasi/app switch
    }

    override fun cycleAspect() {
        val all = AspectMode.entries
        state.aspect = all[(state.aspect.ordinal + 1) % all.size]
        showMessage(state.aspect.label)
    }

    override fun setSpeed(speed: Float) {
        exo?.setPlaybackSpeed(speed)
        showMessage("Kecepatan ${speed}×")
    }

    override fun pickSubtitle() {
        pickSubtitle.launch(arrayOf("*/*"))
    }

    private fun loadExternalSubtitle(uri: Uri) {
        val p = exo ?: return
        val current = p.currentMediaItem ?: return
        val name = displayName(uri).lowercase()
        val mime = when {
            name.endsWith(".ass") || name.endsWith(".ssa") -> MimeTypes.TEXT_SSA
            name.endsWith(".vtt") -> MimeTypes.TEXT_VTT
            else -> MimeTypes.APPLICATION_SUBRIP
        }
        val sub = MediaItem.SubtitleConfiguration.Builder(uri)
            .setMimeType(mime)
            .setLanguage("und")
            .setLabel(displayName(uri))
            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
            .build()
        val index = p.currentMediaItemIndex
        val pos = p.currentPosition
        p.replaceMediaItem(index, current.buildUpon().setSubtitleConfigurations(listOf(sub)).build())
        p.seekTo(index, pos)
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).build()
        showMessage("Subtitle dimuat: ${displayName(uri)}")
    }

    override fun selectTrack(type: Int, group: Tracks.Group?, trackIndex: Int) {
        val p = exo ?: return
        val b = p.trackSelectionParameters.buildUpon()
        if (group == null) {
            b.setTrackTypeDisabled(type, true) // "Mati"
        } else {
            b.setTrackTypeDisabled(type, false)
            b.setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, trackIndex))
        }
        p.trackSelectionParameters = b.build()
    }

    override fun exit() { finish() }

    // ---------- Lifecycle ----------

    override fun onStop() {
        super.onStop()
        saveResume()
        val p = exo ?: return
        wasPlayingBeforeStop = p.playWhenReady
        p.playWhenReady = false // default: hanya foreground
    }

    override fun onStart() {
        super.onStart()
        if (wasPlayingBeforeStop) exo?.playWhenReady = true
        wasPlayingBeforeStop = false
    }

    override fun onDestroy() {
        saveResume()
        exo?.removeListener(listener)
        exo?.release()
        exo = null
        super.onDestroy()
    }
}
