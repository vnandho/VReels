package com.vreels.player.core.design

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import com.vreels.player.core.settings.ThemeMode

// Desain terinspirasi gaya aplikasi musik modern: latar hampir hitam, aksen hijau, kartu abu gelap.
// Tidak memakai logo, nama, atau aset merek mana pun.
val VBackground = Color(0xFF121212)
val VCard = Color(0xFF2A2A2A)
val VSecondary = Color(0xFFB3B3B3)

val AccentColors = listOf(
    "Hijau" to Color(0xFF1DB954),
    "Cyan" to Color(0xFF26C6DA),
    "Coral" to Color(0xFFFF5A5F),
    "Amber" to Color(0xFFFFB300),
)

val TilePalette = listOf(
    Color(0xFFE13300), Color(0xFF1E3264), Color(0xFF8D67AB), Color(0xFF148A08),
    Color(0xFFBA5D07), Color(0xFF477D95), Color(0xFFE8115B), Color(0xFF503750),
)

@Composable
fun ReelsTheme(mode: ThemeMode, accentIndex: Int, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    val accent = AccentColors.getOrElse(accentIndex) { AccentColors[0] }.second
    val scheme = if (dark) darkColorScheme(
        primary = accent, onPrimary = Color.Black,
        background = VBackground, onBackground = Color.White,
        surface = VBackground, onSurface = Color.White,
        surfaceVariant = VCard, onSurfaceVariant = VSecondary,
        secondaryContainer = VCard, onSecondaryContainer = Color.White,
        surfaceContainer = Color(0xFF181818), surfaceContainerHigh = Color(0xFF282828),
        outline = Color(0xFF727272),
    ) else lightColorScheme(primary = accent, onPrimary = Color.Black)
    MaterialTheme(colorScheme = scheme, content = content)
}

/** Chip berbentuk pil: hijau saat dipilih, abu gelap saat tidak. */
@Composable
fun PillChip(selected: Boolean, onClick: () -> Unit, label: String) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label, fontWeight = FontWeight.Medium) },
        shape = RoundedCornerShape(50),
        border = null,
        colors = FilterChipDefaults.filterChipColors(
            containerColor = VCard,
            labelColor = Color.White,
            selectedContainerColor = MaterialTheme.colorScheme.primary,
            selectedLabelColor = Color.Black,
        ),
    )
}
