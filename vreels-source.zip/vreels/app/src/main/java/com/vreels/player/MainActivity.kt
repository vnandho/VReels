package com.vreels.player

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.vreels.player.core.design.ReelsTheme
import com.vreels.player.core.model.GalleryItem
import com.vreels.player.core.model.MediaAccess
import com.vreels.player.core.model.QueueEntry
import com.vreels.player.core.settings.AppSettings
import com.vreels.player.core.settings.SettingsRepository
import com.vreels.player.feature.gallery.GalleryScreen
import com.vreels.player.feature.gallery.GalleryViewModel
import com.vreels.player.feature.gallery.ImageViewerScreen
import com.vreels.player.feature.player.PlayerActivity
import com.vreels.player.feature.settings.SettingsScreen
import kotlinx.coroutines.launch

private enum class Screen { GALLERY, SETTINGS }

class MainActivity : ComponentActivity() {
    private val vm: GalleryViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val repo = SettingsRepository(applicationContext)
        setContent {
            val settings by repo.flow.collectAsStateWithLifecycle(initialValue = AppSettings())
            ReelsTheme(settings.theme, settings.accentIndex) {
                Surface(Modifier.fillMaxSize()) { App(vm, repo, settings) }
            }
        }
    }
}

private val mediaPermissions = arrayOf(
    Manifest.permission.READ_MEDIA_IMAGES,
    Manifest.permission.READ_MEDIA_VIDEO,
    Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED,
)

private fun checkMediaAccess(ctx: android.content.Context): MediaAccess {
    fun granted(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    return when {
        granted(Manifest.permission.READ_MEDIA_IMAGES) && granted(Manifest.permission.READ_MEDIA_VIDEO) -> MediaAccess.FULL
        granted(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) ||
            granted(Manifest.permission.READ_MEDIA_IMAGES) || granted(Manifest.permission.READ_MEDIA_VIDEO) -> MediaAccess.PARTIAL
        else -> MediaAccess.DENIED
    }
}

@Composable
private fun App(vm: GalleryViewModel, repo: SettingsRepository, settings: AppSettings) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var screen by rememberSaveable { mutableStateOf(Screen.GALLERY) }
    var viewer by remember { mutableStateOf<Pair<List<GalleryItem>, Int>?>(null) }
    var access by remember { mutableStateOf(checkMediaAccess(ctx)) }
    var askedOnce by rememberSaveable { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        access = checkMediaAccess(ctx)
        if (access != MediaAccess.DENIED) vm.refresh()
    }
    val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            ctx.startActivity(
                Intent(ctx, PlayerActivity::class.java).apply {
                    action = Intent.ACTION_VIEW
                    setDataAndType(uri, "video/*")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                },
            )
        }
    }

    // Urutan sort awal mengikuti pengaturan tersimpan (sekali saja).
    LaunchedEffect(settings.sortOrder) { vm.sort.value = settings.sortOrder }
    // Refresh setiap kali kembali ke gallery / izin berubah di Settings Android.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        access = checkMediaAccess(ctx)
        if (access != MediaAccess.DENIED) vm.refresh()
    }
    LaunchedEffect(Unit) {
        if (access == MediaAccess.DENIED && !askedOnce) {
            askedOnce = true
            permissionLauncher.launch(mediaPermissions)
        }
    }

    BackHandler(enabled = viewer != null) { viewer = null }
    BackHandler(enabled = viewer == null && screen == Screen.SETTINGS) { screen = Screen.GALLERY }
    BackHandler(enabled = viewer == null && screen == Screen.GALLERY) {
        if (!vm.backToFolders()) (ctx as? ComponentActivity)?.finish()
    }

    val currentViewer = viewer
    when {
        currentViewer != null -> ImageViewerScreen(currentViewer.first, currentViewer.second) { viewer = null }
        screen == Screen.SETTINGS -> SettingsScreen(settings, repo) { screen = Screen.GALLERY }
        else -> GalleryScreen(
            vm = vm,
            gridColumns = settings.gridColumns,
            access = access,
            onRequestAccess = { permissionLauncher.launch(mediaPermissions) },
            onOpenVideo = { item ->
                val (queue, index) = vm.buildQueue(item, settings.queueScope)
                launchPlayer(ctx, queue, index)
            },
            onOpenImage = { item, images -> viewer = images to images.indexOfFirst { it.id == item.id }.coerceAtLeast(0) },
            onPickVideoFile = { pickVideo.launch(arrayOf("video/*")) },
            onOpenSettings = { screen = Screen.SETTINGS },
            onSortChange = { order -> scope.launch { repo.update { it.copy(sortOrder = order) } } },
            onGridChange = { n -> scope.launch { repo.update { it.copy(gridColumns = n) } } },
        )
    }
}

private fun launchPlayer(ctx: android.content.Context, queue: List<QueueEntry>, index: Int) {
    if (queue.isEmpty()) return
    com.vreels.player.playback.queue.PlaybackQueueStore.items = queue
    ctx.startActivity(Intent(ctx, PlayerActivity::class.java).putExtra(PlayerActivity.EXTRA_INDEX, index))
}
