package com.vreels.player.playback.queue

import com.vreels.player.core.model.QueueEntry
import com.vreels.player.core.settings.QueueBoundary

/** Hasil navigasi antrean. [index] null berarti tidak berpindah. */
data class NavResult(val index: Int?, val showMessage: Boolean)

object QueueNavigator {
    fun target(current: Int, size: Int, forward: Boolean, boundary: QueueBoundary): NavResult {
        if (size <= 0) return NavResult(null, false)
        val next = if (forward) current + 1 else current - 1
        if (next in 0 until size) return NavResult(next, false)
        return when (boundary) {
            QueueBoundary.STOP -> NavResult(null, false)
            QueueBoundary.MESSAGE -> NavResult(null, true)
            QueueBoundary.WRAP -> if (size == 1) NavResult(null, false)
            else NavResult(if (forward) 0 else size - 1, false)
        }
    }
}

/**
 * Antrean antar-layar dalam satu proses. Dipakai agar daftar video yang panjang
 * tidak dikirim lewat Intent (batas ukuran Binder ~1 MB).
 */
object PlaybackQueueStore {
    @Volatile var items: List<QueueEntry> = emptyList()
}
