package com.vreels.player.core.media

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import android.net.Uri
import com.vreels.player.core.model.GalleryItem
import com.vreels.player.core.model.MediaType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Membaca foto & video dari MediaStore (hanya yang boleh diakses sesuai izin Android). */
class MediaRepository(private val context: Context) {

    suspend fun load(): List<GalleryItem> = withContext(Dispatchers.IO) {
        val collection = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL)
        val projection = arrayOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_ADDED,
            MediaStore.Files.FileColumns.MEDIA_TYPE,
            MediaStore.MediaColumns.BUCKET_ID,
            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME,
            MediaStore.MediaColumns.DURATION,
        )
        val selection = "${MediaStore.Files.FileColumns.MEDIA_TYPE} IN (?, ?)"
        val args = arrayOf(
            MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE.toString(),
            MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO.toString(),
        )
        val out = ArrayList<GalleryItem>()
        runCatching {
            context.contentResolver.query(collection, projection, selection, args, null)?.use { c ->
                val iId = c.getColumnIndexOrThrow(projection[0])
                val iName = c.getColumnIndexOrThrow(projection[1])
                val iSize = c.getColumnIndexOrThrow(projection[2])
                val iDate = c.getColumnIndexOrThrow(projection[3])
                val iType = c.getColumnIndexOrThrow(projection[4])
                val iBucket = c.getColumnIndexOrThrow(projection[5])
                val iBucketName = c.getColumnIndexOrThrow(projection[6])
                val iDur = c.getColumnIndexOrThrow(projection[7])
                while (c.moveToNext()) {
                    val id = c.getLong(iId)
                    val isVideo = c.getInt(iType) == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO
                    val base = if (isVideo) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                    else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                    out += GalleryItem(
                        id = id,
                        uri = ContentUris.withAppendedId(base, id),
                        name = c.getString(iName) ?: "",
                        type = if (isVideo) MediaType.VIDEO else MediaType.IMAGE,
                        sizeBytes = c.getLong(iSize),
                        dateAdded = c.getLong(iDate),
                        durationMs = if (isVideo) c.getLong(iDur) else 0L,
                        bucketId = c.getLong(iBucket),
                        bucketName = c.getString(iBucketName) ?: "Lainnya",
                    )
                }
            }
        }
        out
    }
}

/** Thumbnail lokal dari sistem Android; tidak ada pemuatan gambar dari jaringan. */
object ThumbnailLoader {
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 1024 / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount / 1024
    }

    suspend fun load(context: Context, uri: Uri, sizePx: Int): Bitmap? = withContext(Dispatchers.IO) {
        val key = "$uri@$sizePx"
        cache.get(key) ?: runCatching {
            context.contentResolver.loadThumbnail(uri, Size(sizePx, sizePx), null)
        }.getOrNull()?.also { cache.put(key, it) }
    }
}
