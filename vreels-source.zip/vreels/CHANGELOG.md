# Changelog
## 1.1.0 (source, belum dibuild)
- Desain ulang bergaya Spotify: Beranda/Cari/Pustaka dengan bottom navigation, halaman koleksi, chip pil, tema gelap + aksen hijau, player bergaya serupa.
- Aplikasi diganti nama menjadi vreels (`com.vreels.player`).

## 1.0.0 (source awal, belum dibuild)
- Gallery foto/video: grid, folder, filter, cari, urutkan, pull-to-refresh, izin Android 14 (penuh/sebagian), buka file lewat pemilih.
- Penampil foto sederhana.
- Player Media3: tap hanya toggle kontrol, gesture brightness/volume/next-previous, timeline, speed, aspect, repeat, rotasi (kunci orientasi), fullscreen immersive, subtitle (embedded + file eksternal), audio track, resume, decoder Auto/Hardware/Software.
- Settings tersimpan lokal (DataStore): tema, aksen, grid, gesture, kontrol (ukuran, urutan, visibilitas, posisi, gaya ikon, transparansi).
- Unit test: GestureClassifier (17) dan QueueNavigator (5).
