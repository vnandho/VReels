# Serah terima ke Claude Code (untuk menghasilkan APK)

Source project ini ditulis di chat claude.ai, yang tidak punya Android SDK maupun akses ke server Google/Maven.
Jadi **belum pernah dikompilasi** menjadi APK. Langkah terakhir ini dikerjakan Claude Code, bukan Anda.

## Cara pakai
1. Ekstrak `vreels-source.zip` ke folder kosong.
2. Buka folder itu di Claude Code (Claude Desktop → tab Code, atau CLI).
3. Tempel pesan berikut:

```text
Proyek Android "vreels" di folder ini sudah punya source lengkap tetapi belum pernah dikompilasi.
Baca README.md, BUILD_REPORT.md, dan Reels_Gallery_Master_Prompt_Claude.md (jika ada).
Tugasmu: menghasilkan APK debug yang benar-benar terpasang di Android 14+.
1. Periksa JDK 17+, pasang Android command-line tools, platform android-36, dan build-tools lewat sdkmanager resmi.
2. Buat Gradle wrapper (gradle wrapper --gradle-version 8.13) karena gradle-wrapper.jar belum ada.
3. Jalankan scripts/build-and-verify.sh. Perbaiki semua error kompilasi/lint secara minimal tanpa mengubah perilaku
   yang tertulis di README (terutama aturan tap, gesture, dan zona).
4. Jika versi di gradle/libs.versions.toml sudah ada yang lebih baru dan stabil, boleh dinaikkan bila perlu, catat di BUILD_REPORT.md.
5. Jalankan emulator API 34+ jika tersedia dan lakukan smoke test; jika tidak ada, tulis jujur bahwa belum diuji di perangkat.
6. Perbarui BUILD_REPORT.md dengan hasil nyata (apa yang lulus, apa yang gagal, apa yang tidak dijalankan).
7. Letakkan hasil di dist/ dan beri tahu saya lokasi APK-nya. Jangan menaruh file placeholder.
Jangan menambahkan izin INTERNET, iklan, analytics, atau SDK pelacak.
```

## Yang sudah terbukti (di chat)
Logika `GestureClassifier` dan `QueueNavigator` dikompilasi dengan Kotlin 2.3.21 dan 22 unit test lulus.
Semua kode lain (Compose, Media3, MediaStore, DataStore) **belum** dikompilasi.
