# Privasi vreels

- Aplikasi **tidak memiliki izin INTERNET** dan tidak membuat koneksi jaringan.
- Tidak ada iklan, analytics, pelacak, login, atau konfigurasi jarak jauh.
- Foto/video dibaca dari perangkat melalui MediaStore sesuai izin yang Anda berikan (akses penuh atau hanya item pilihan di Android 14+).
- File yang dibuka lewat pemilih file dibaca lewat URI dari Android; aplikasi tidak menyalinnya.
- Pengaturan (DataStore) dan posisi lanjut-putar (SharedPreferences) disimpan lokal di perangkat. `allowBackup` dimatikan.
- Tidak ada data yang dikirim ke pihak mana pun.
