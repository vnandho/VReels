# Arsitektur ringkas
- **Satu modul `:app`**, tanpa DI framework. State UI: ViewModel + StateFlow (gallery), `PlayerUiState` (player), DataStore (pengaturan).
- **Dua Activity:** `MainActivity` (gallery/settings/foto) dan `PlayerActivity` (fullscreen). Player terpisah agar rotasi, brightness jendela, dan immersive mode dikelola sendiri, dan state gallery (scroll/filter/folder) tetap hidup saat kembali.
- **Gesture:** `GestureClassifier` murni Kotlin. `PlayerScreen` menumpuk 3 layer: video → surface gesture → kontrol. Hanya elemen interaktif kontrol yang menangkap sentuhan, sisanya jatuh ke surface gesture.
- **Antrean:** daftar video dikirim lewat `PlaybackQueueStore` (in-process) + index di Intent, untuk menghindari batas ukuran Binder. Jika proses mati, player menutup dirinya.
- **Engine:** saat ini langsung ExoPlayer. Abstraksi `PlaybackEngine` yang diminta spesifikasi belum dibuat; UI hanya bergantung pada `androidx.media3.common.Player` + `PlayerActions`, sehingga penggantian engine masih perlu refactor.
- **Privasi:** tanpa izin INTERNET, `allowBackup=false`.
