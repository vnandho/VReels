#!/usr/bin/env bash
# Build + verifikasi vreels. Dijalankan oleh Claude Code (atau manual) di mesin yang punya JDK 17+ dan akses internet build-time.
# Output ke dist/. Skrip ini berhenti pada kegagalan pertama dan TIDAK menyembunyikan error.
set -euo pipefail
cd "$(dirname "$0")/.."

[ -x ./gradlew ] || { echo "gradlew tidak ada. Buat dulu: gradle wrapper --gradle-version 8.13 (atau buka di Android Studio)"; exit 1; }
: "${ANDROID_HOME:=${ANDROID_SDK_ROOT:-$HOME/Android/Sdk}}"
[ -d "$ANDROID_HOME" ] || { echo "ANDROID_HOME tidak ditemukan ($ANDROID_HOME). Pasang Android command-line tools + platform android-36 + build-tools via sdkmanager."; exit 1; }
echo "sdk.dir=$ANDROID_HOME" > local.properties

./gradlew --version
./gradlew clean
./gradlew testDebugUnitTest
./gradlew lintDebug
./gradlew assembleDebug

APK=$(ls app/build/outputs/apk/debug/*.apk | head -n1)
mkdir -p dist
OUT="dist/vreels-v1.0.0-android14plus-debug.apk"
cp "$APK" "$OUT"
[ -s "$OUT" ] || { echo "APK kosong"; exit 1; }

BT=$(ls -d "$ANDROID_HOME"/build-tools/* | sort -V | tail -n1)
echo "== apksigner"; "$BT/apksigner" verify --verbose "$OUT" | head -5
echo "== badging";   "$BT/aapt2" dump badging "$OUT" | grep -E "^package|sdkVersion|targetSdkVersion|uses-permission"
if "$BT/aapt2" dump permissions "$OUT" | grep -q "android.permission.INTERNET"; then
  echo "GAGAL: APK meminta INTERNET"; exit 1
else
  echo "OK: tidak ada izin INTERNET"
fi
( cd dist && sha256sum "$(basename "$OUT")" > SHA256SUMS.txt && cat SHA256SUMS.txt )
echo "Selesai. Isi dist/:"; ls -la dist
