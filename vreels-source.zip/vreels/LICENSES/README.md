# Lisensi pihak ketiga

Aplikasi ini memakai pustaka AndroidX/Jetpack: Compose, Activity, Lifecycle, DataStore, Core KTX, dan **Media3 (ExoPlayer)**.
Semuanya berlisensi **Apache License 2.0** (https://www.apache.org/licenses/LICENSE-2.0).

Tidak ada komponen LGPL/GPL dan tidak ada kode, aset, atau merek VLC/MX Player/aplikasi lain di project ini.
Jika kelak engine diganti ke LibVLC (LGPL), wajib menambahkan notice dan teks lisensinya di sini.
Sebelum rilis publik, buat ulang daftar lisensi dari dependency yang benar-benar terpasang (mis. `./gradlew :app:dependencies`).
