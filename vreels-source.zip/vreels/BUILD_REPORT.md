# BUILD_REPORT (diisi jujur)

| Item | Status |
|---|---|
| Unit test `GestureClassifier` (17) + `QueueNavigator` (5) | **LULUS 22/22**. Dikompilasi dengan kotlinc 2.3.21 asli, memakai shim JUnit minimal karena jar JUnit tidak bisa diunduh di lingkungan penulisan. Perlu dijalankan ulang lewat `./gradlew testDebugUnitTest`. |
| Kompilasi seluruh app (Compose/Media3/MediaStore/DataStore) | **BELUM dijalankan.** Lingkungan penulisan tidak punya Android SDK dan tidak bisa mengakses dl.google.com / maven.google.com. Mungkin ada error kompilasi kecil. |
| `lintDebug`, `assembleDebug`, `assembleRelease` | **BELUM dijalankan** |
| APK dibuat / signature / merged manifest / SHA-256 | **BELUM ada.** `dist/` belum berisi APK. |
| Uji di emulator/perangkat (gesture, subtitle, resume, dll.) | **BELUM dilakukan** |
| Izin INTERNET | Tidak dideklarasikan di manifest app. **Merged manifest belum diperiksa**; `scripts/build-and-verify.sh` memeriksanya setelah build. |

| Desain UI baru (gaya Spotify) | Ditulis, **belum dikompilasi dan belum dilihat di layar**. Tampilan sebenarnya bisa berbeda dari yang dibayangkan sampai dijalankan di perangkat. |

## Versi (dicek ke dokumentasi resmi developer.android.com, 9 Nov 2026)
AGP 8.13.2, Gradle 8.13, Kotlin 2.3.21, Compose BOM 2026.08.00, Activity-Compose 1.13.0, Lifecycle 2.10.0, Media3 1.9.0, DataStore 1.2.1, Core KTX 1.17.0. compileSdk/targetSdk 36, minSdk 34.
Catatan: `gradle-wrapper.jar` dan skrip `gradlew` belum ada (tidak bisa diunduh di lingkungan penulisan); buat dengan `gradle wrapper --gradle-version 8.13`.

## Area berisiko saat kompilasi pertama
- API `MediaCodecSelector`/`MediaCodecUtil` Media3 (opt-in UnstableApi) untuk pilihan decoder.
- Nama ikon Material (material-icons-extended) dan alias import ikon outlined.
- `PullToRefreshBox` (eksperimental Material3) dan `LifecycleEventEffect`.
- Seluruh `GalleryScreen.kt` baru (banyak API Compose/Material3, mis. NavigationBar, PullToRefreshBox, grid span).
- Ukuran APK debug besar karena icons-extended tanpa R8; build release akan menyusutkan.
